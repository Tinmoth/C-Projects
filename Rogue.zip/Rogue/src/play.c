/*********************
Student Name: Timothy Bratcher      Student Number:0902130
Date: March 13, 2015             Course Name: CIS2500
I have exclusive control over this submission via my password.
By including this statement in this header comment, I certify that:
    1)I have read and understood the University policy on academic integrity;
    2)I have completed the Computing with Integrity Tutorial on Moodle; and
    3)I have achieved at least 80% in the Computing with Integrity Self Test.
I assert that this work is my own. I have appropriately acknowledged any and all material
(data, images, ideas or words) that I have used, whether directly quoted or paraphrased.
Furthermore, I certify that this assignment was prepared by me specifically for this course.
*********************/
#include "dungeon.h"
#include "play.h"
/**************
crawl: navigates the dungeon and picks up items
In: Hero * hero, char keystroke, int yCoords[], int xCoords[], char * * inventory
Out: int inventID
Post: returns a list of all items picked up
**************/
int crawl(Hero * hero, char keystroke, int yCoords[], int xCoords[], char * * inventory)
{
    int currX;
    int currY;
    hero->floorTile = ' ';
    currX = hero->x;
    currY = hero->y;
    int inventID = 0;
    //movement controls
    while (keystroke != 'q')
    {
        if (keystroke == 'w')
            hero->y--;
        if (keystroke == 'a')
            hero->x--;
        if (keystroke == 's')
            hero->y++;
        if (keystroke == 'd')
            hero->x++;
        // block walking over walls or monsters
        if ((mvinch(hero->y,hero->x) == '-')||
            (mvinch(hero->y,hero->x) == '|')||
            (mvinch(hero->y,hero->x) == 'M'))
        {
            hero->y = currY;
            hero->x = currX;
        }
        // move through doors to the next room 1>2>3>4>5>6>1 etc
        else if (mvinch(hero->y,hero->x) == '+')
        {
            if (hero->roomNo == 1)
            {
                hero->y = yCoords[hero->roomNo];
                hero->x = xCoords[hero->roomNo];
                hero->roomNo = 2;
            }
            else if (hero->roomNo == 2)
            {
                hero->y = yCoords[hero->roomNo];
                hero->x = xCoords[hero->roomNo];
                hero->roomNo = 3;
            }
            else if (hero->roomNo == 3)
            {
                hero->y = yCoords[hero->roomNo];
                hero->x = xCoords[hero->roomNo];
                hero->roomNo = 4;
    	    }
	        else if (hero->roomNo == 4)
            {
	            hero->y = yCoords[hero->roomNo];
                hero->x = xCoords[hero->roomNo];
                hero->roomNo = 5;
	        }
	        else if (hero->roomNo == 5)
            {
	            hero->y = yCoords[hero->roomNo];
                hero->x = xCoords[hero->roomNo];
	            hero->roomNo = 6;
            }
	        else if (hero->roomNo == 6)
	        {
	            hero->y = yCoords[0];
                hero->x = xCoords[0];
    	        hero->roomNo = 1;
            }
        }
        mvaddch(currY,currX,hero->floorTile);
        hero->floorTile = mvinch(hero->y,hero->x);
        // pick up items
        if (hero->floorTile == '!')
        {
            inventory[inventID] = malloc(sizeof(char)*10);
            strcpy(inventory[inventID],"a potion");
            inventID++;
            hero->floorTile = ' ';
        }
        else if (hero->floorTile == '=')
        {
            inventory[inventID] = malloc(sizeof(char)*15);
            strcpy(inventory[inventID],"a magic item");
            inventID++;
            hero->floorTile = ' ';
        }
        else if (hero->floorTile == '/')
        {
            inventory[inventID] = malloc(sizeof(char)*10);
            strcpy(inventory[inventID],"a weapon");
            inventID++;
            hero->floorTile = ' ';
        }
        else if (hero->floorTile == '*')
        {
            inventory[inventID] = malloc(sizeof(char)*10);
            strcpy(inventory[inventID],"some gold");
            inventID++;
            hero->floorTile = ' ';
        }
	//replace the proper characters on the floor
        mvaddch(hero->y,hero->x,hero->heroMark);
        currY = hero->y;
        currX = hero->x;
        refresh();
        keystroke = getch();
    }
    return (inventID); //returns the number of items in the inventory
}
