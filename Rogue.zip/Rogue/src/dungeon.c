/*********************
Student Name: Timothy Bratcher      Student Number:0902130
Date: March 13, 2015             Course Name: CIS2500
I have exclusive control over this submission via my password.
By including this statement in this header comment, I certify that:
    1)I have read and understood the University policy on academic integrity;
    2)I have completed the Computing with Integrity Tutorial on Moodle; and
    3)I have achieved at least 80% in the Computing with Integrity Self Test.
I assert that this work is my own. I have appropriately acknowledged any and all material
(data, images, ideas or words) that I have used, whether directly quoted or paraphrased.
Furthermore, I certify that this assignment was prepared by me specifically for this course.
*********************/
#include "dungeon.h"

/***********
drawRoom: places doors and objects in a room
In: Room * thisR, Hero * hero
Out: None
Post: rooms are populated
***********/
void drawRoom (Room * thisR, Hero * hero)
{
    int val;
    char item, door, direct;
    int objY;
    int objX;
    for (int i = 1; i < thisR->commNum; i++)
    {
        if (thisR->attrib[i][0] == 'd') //draw doors
        {
            sscanf(thisR->attrib[i],"%c%c%d",&door,&direct,&val);
            
            if (direct == 'e')
                mvaddch((thisR->y+val),(thisR->x+thisR->width),'+');
            //val = thisR->attrib[i][2] - '0'; // tip from www.stackoverflow.com user Paul Tomblin, posted May 15, 2009
            else if (direct == 'n')
                mvaddch((thisR->y-1),(thisR->x+val),'+');
            else if (direct == 's')
                mvaddch((thisR->y+thisR->length),(thisR->x+val),'+');
            else if (direct == 'w')
                mvaddch((thisR->y+val),(thisR->x-1),'+');
        }
        else if ((thisR->attrib[i][0] == 'p')||(thisR->attrib[i][0] == 'g')||//potions, gold, Monsters, magic, hero, weapons
                (thisR->attrib[i][0] == 'M')||(thisR->attrib[i][0] == 'm')||
                (thisR->attrib[i][0] == 'h')||(thisR->attrib[i][0] == 'w')||
                (thisR->attrib[i][0] == 's'))
        {
            sscanf(thisR->attrib[i],"%c%d,%d",&item,&objY,&objX);
            if (item == 'g')
                mvaddch((thisR->y+objY),(thisR->x+objX),'*');
            else if (item == 'p')
                mvaddch((thisR->y+objY),(thisR->x+objX),'!');
            else if (item == 'M')
                mvaddch((thisR->y+objY),(thisR->x+objX),'M');
            else if (item == 's')
                mvaddch((thisR->y+objY),(thisR->x+objX),'%');
            else if (item == 'm')
                mvaddch((thisR->y+objY),(thisR->x+objX),'=');
            else if (item == 'w')
                mvaddch((thisR->y+objY),(thisR->x+objX),'/');
            else if (item == 'h')
            {
                hero->y = thisR->y+objY;
                hero->x = thisR->x+objX;
                hero->roomNo = thisR->roomNo;
                mvaddch(hero->y,hero->x,hero->heroMark);
            }
        }
    }
}
/**************
makeRoom: creates Room objects and initializes all their members
In: char * inString, int y, int x, int roomNum
Out: Room * theRoom
Post: none
**************/
Room * makeRoom(char * inString, int y, int x, int roomNum)
{
	Room * theRoom;
	theRoom = malloc(sizeof(Room));
	theRoom->roomNo = roomNum;
	theRoom->x = x;
	theRoom->y = y;
	theRoom->attrib = malloc(sizeof(char *)*10);
	char * token;
	int p = 0;
	// separates each part of the instruction string into a separate command, to be passed to drawRoom()
	token = strtok(inString, " ");
	while (token != NULL)
	 {
	    theRoom->attrib[p] = malloc(sizeof(char)*(strlen(token)+1));
	    strcpy(theRoom->attrib[p], token);
	    p++;
	    token = strtok(NULL, " ");
	}
	theRoom->commNum = p;
	return (theRoom);
}
