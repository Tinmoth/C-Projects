/*********************
Student Name: Timothy Bratcher      Student Number:0902130
Date: March 13, 2015             Course Name: CIS2500
I have exclusive control over this submission via my password.
By including this statement in this header comment, I certify that:
    1)I have read and understood the University policy on academic integrity;
    2)I have completed the Computing with Integrity Tutorial on Moodle; and
    3)I have achieved at least 80% in the Computing with Integrity Self Test.
I assert that this work is my own. I have appropriately acknowledged any and all material
(data, images, ideas or words) that I have used, whether directly quoted or paraphrased.
Furthermore, I certify that this assignment was prepared by me specifically for this course.
*********************/
#include "dungeon.h"
#include "play.h"

int main (int argc, char * argv[])
{
    int buffer = 100;
    int roomNum = 1;
    int inv = 0;
    char inString[buffer];
    FILE * ofp;
    int yCoords[] = {1, 1, 1, 29, 29, 29};
    int xCoords[] = {1, 30, 60, 60, 30, 1};
    char * * fileLine;
    Room * * allRooms;
    int lnId = 0;
    fileLine = malloc(sizeof(char*)*6);
    allRooms = malloc(sizeof(Room*)*6);
    char * token;
    char * temp;
    char keystroke;
    Hero * hero = malloc(sizeof(Hero)*1); 
    hero->heroMark = '@';
    char * * inventory;
    inventory = malloc(sizeof(char*)*50);

    if (argc == 2)
        ofp = fopen(argv[1], "r");
    else
    {
        printf("Wrong number of parameters\n");
        exit(0);
    }
    if (ofp == NULL)
    {
        printf("bad file name\n");
	    exit(0);
    }
    while ((fgets(inString,buffer,ofp)) != NULL)
    {
        fileLine[lnId] = malloc(sizeof(char)*(strlen(inString)+1));
        strcpy(fileLine[lnId], inString);
        lnId++;
    }// reads in all the lines, saves them to char * * fileLine
    for (int m = 0; m < lnId; m++)
    {
        allRooms[m] = makeRoom(fileLine[m], yCoords[m], xCoords[m], roomNum);
        roomNum++;
    }// makes all the rooms, saves them to Room * * allRooms

    initscr();
    noecho();
    cbreak();
    curs_set(0); //hides cursor. credit to user 'parkydr' at stackoverflow.com, posted sept 17, 2013
    for (int s = 0; s < (roomNum-1); s++)
    {
        token = strtok(allRooms[s]->attrib[0], "X");

        allRooms[s]->length = strtol(token,&temp,0);
        token = strtok(NULL, " ");
        allRooms[s]->width = strtol(token,&temp,0);
        for (int w = -1; w < (allRooms[s]->length+1);w++)
        {
            mvaddch((allRooms[s]->y+w),(allRooms[s]->x-1),'|');
            mvaddch((allRooms[s]->y+w),(allRooms[s]->x+allRooms[s]->width),'|');
        }
        for (int z = -1; z < (allRooms[s]->width+1); z++)
        {
            mvaddch((allRooms[s]->y-1),(allRooms[s]->x+z),'-');
            mvaddch((allRooms[s]->y+allRooms[s]->length),(allRooms[s]->x+z),'-');
        }
        drawRoom(allRooms[s],hero);
    }// takes parsed attribs and places items/hero/monsters
    move(hero->y,hero->x);
    mvaddch(hero->y,hero->x,hero->heroMark);
    keystroke = getch();
    inv = crawl(hero,keystroke,yCoords,xCoords,inventory);
    getch();
    endwin();
    //print inventory
    printf("Inventory: \n");
    for (int h = 0; h < inv; h++)
        printf("%s\n",inventory[h]);
    //free all the malloc'd memory
    for (int k = 0; k < lnId; k++)
    {
        free(fileLine[k]);
    }
    free(fileLine);
    for (int n = 0; n < lnId; n++)
    {
        for (int q = 0; q < allRooms[n]->commNum; q++)
        {
            free(allRooms[n]->attrib[q]);
        }
        free(allRooms[n]->attrib);
        free(allRooms[n]);
    }
    for (int g = 0; g < inv; g++)
    {
        free(inventory[inv]);
    }
    free(inventory);
    free(allRooms);
    free(hero);
    fclose(ofp);
    return (0);
}
