#ifndef _TBRATCHE_DUNGEONH
#define _TBRATCHE_DUNGEONH

#include <stdlib.h>
#include <ncurses.h>
#include <string.h>
#include <stdio.h>

typedef struct Hero
{
    char floorTile;
    char heroMark;
    int y;
    int x;
    int roomNo;
}Hero;
typedef struct Room
{
    int roomNo;
    char * * attrib;
    int commNum;
    int y;
    int x;
    long width;
    long length;
}Room;

/***********
drawRoom: places doors and objects in a room
In: Room * thisR, Hero * hero
Out: None
Post: rooms are populated
***********/
void drawRoom (Room * thisR, Hero * hero);
/**************
makeRoom: creates Room objects and initializes all their members
In: char * inString, int y, int x, int roomNum
Out: Room * theRoom
Post: none
**************/
Room * makeRoom(char * inString, int y, int x, int roomNum);
#endif