#ifndef _TBRATCHE_PLAYH
#define _TBRATCHE_PLAYH

#include <stdlib.h>
#include <ncurses.h>
#include <string.h>
#include <stdio.h>
#include "dungeon.h"

/**************
crawl: navigates the dungeon and picks up items
In: Hero * hero, char keystroke, int yCoords[], int xCoords[], char * * inventory
Out: int inventID
Post: returns a list of all items picked up
**************/
int crawl(Hero * hero,char keystroke, int yCoord[], int xCoord[], char * * inventory);

#endif