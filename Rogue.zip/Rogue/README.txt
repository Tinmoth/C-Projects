Student Name: Timothy Bratcher
ID: 0902130
Course: CIS2500
Date: March 13, 2015

Filename: a3.c, dungeon.c, play.c
Header files: rogue.h, move.h
Input file: user-specified

Compiling:
gcc -Wall -std=c99 src/a3.c src/dungeon.c src/play.c -Iinclude -o runMe -lncurses

Running:
./bin/runMe

Limitations:
Regardless of which door is entered, the hero moves in a set sequence
through the rooms. 1>2>3>4>5>6>1 in a clockwise manner. Hero appears in the top left corner
of the new room. Traveling into a room with no doors gets the player stuck. 
(But seriously who builds a room with no doors?)

Items must be placed at coordinates less than the dimensions of the room, 
e.g. a potion in a room 10x10 must be at coordinates 9,9 or less.

Items placed on top of another item will destroy the one below. They are very heavy, yet very fragile.

If rooms are drawn beyond edge of window, moving the player below the window
edge allows for travel outside a room. Player can reenter by going through a door.

Notes:
To implement combat:
Monsters would have to be structs much like heros.
Each would have to have an HP element as well as DPS. Each time WASD was pressed
towards a monster, the hero HP and monster HP could be decremented according to a random
amount within the bounds of the DPS variable. A play-by-play could be printed
outside the dungeon diagram (reserve top line, like in rogue3.6.3).

