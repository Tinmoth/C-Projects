#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "linkedList.h"

int main()
{
    double cal = 50;
    char food[] = "broccoli";
    char group[] = "vegfruit";
    char type = 'h';
    double cal2 = 75;
    char food2[] = "cheetos";
    char group2[] = "fat";
    char type2 = 'j';
    Food * temp;
/*    char * record;
    char * record2;*/
    Food * edible;
    Food * edible2;
    Food * theList = NULL; /* starts the list off null*/
    
    edible = createRecord(food, group, cal, type);
    edible2 = createRecord(food2, group2, cal2, type2);
    /* both elements are created*/
    theList = addToFront(theList, edible);
/*    record = printRecord(theList);*/
    theList = addToBack(theList, edible2);
/*    record2 = printRecord(theList->next);*/
/*    puts(record);
    puts(record2);*/
/*    printList(theList);*/
    temp = getLastItem(theList);
/*    theList = removeFromBack(theList);*/
    printList(theList);
    printList(temp);
    free(temp);
    destroyList(theList); 

    /*
    record = printRecord(edible);
    puts(record);
    record2 = printRecord(edible2);
    puts(record2);
    */
    free(edible);
    free(edible2);
/*    free(record);
    free(record2);*/
    return(0);
}