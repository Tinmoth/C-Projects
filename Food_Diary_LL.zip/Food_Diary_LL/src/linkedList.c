/*********************
Student Name: Timothy Bratcher      Student Number:0902130
Date: April 1, 2015                 Course Name: CIS2500
I have exclusive control over this submission via my password.
By including this statement in this header comment, I certify that:
    1)I have read and understood the University policy on academic integrity;
    2)I have completed the Computing with Integrity Tutorial on Moodle; and
    3)I have achieved at least 80% in the Computing with Integrity Self Test.
I assert that this work is my own. I have appropriately acknowledged any and all material
(data, images, ideas or words) that I have used, whether directly quoted or paraphrased.
Furthermore, I certify that this assignment was prepared by me specifically for this course.
*********************/
#include "linkedList.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

Food * createRecord(char * name, char * group, double calories, char theType)
{
    Food * newFood = malloc(sizeof(Food));
    newFood->name = malloc(sizeof(char)*(strlen(name)+1));
    strcpy(newFood->name, name);
    newFood->foodGroup = malloc(sizeof(char)*(strlen(group)+1));
    strcpy(newFood->foodGroup, group);
    newFood->calories = calories;
    newFood->type = theType;
    newFood->next = NULL;

    return(newFood);
}

char * printRecord(Food * toPrint)
{
    char * record = malloc(sizeof(char)*50);
    sprintf(record, "%s (%s):%.2lf[%c]",toPrint->name,toPrint->foodGroup,toPrint->calories,toPrint->type);
    return (record);
}

void destroyElement(Food * theElement)
{
    free(theElement->name);
    free(theElement->foodGroup);
}

/*****************
List Operations
*****************/

Food * addToFront(Food * theList, Food * toBeAdded)
{
    toBeAdded->next = theList;
    return (toBeAdded);
}

Food * addToBack(Food * theList, Food * toBeAdded)
{
    if (theList == NULL)
        return (toBeAdded);
    else
    {
        Food * temp = theList;
        while (temp->next != NULL)
        {
            temp = temp->next;
        }
        temp->next = toBeAdded;
        return (theList);
    }
}

Food * removeFromFront(Food * theList)
{
    if (theList == NULL)
        return NULL;
    else
    {
        if (theList->next == NULL)
        {
            theList = NULL;
            return theList;
        }
        else
        {
            theList = theList->next;
            return theList;
        }
    }
}

Food * removeFromBack(Food * theList)
{
    if (theList == NULL)
        return NULL;
    else
    {
        Food * temp = theList;
        if (temp->next == NULL)
        {
            theList = NULL;
            return theList;
        }
        else
        {
            while (temp->next->next != NULL)
            {
                temp = temp->next;
            }
            temp->next = NULL;
            return theList;
        }
    }
}

Food * getLastItem(Food * theList)
{
    if (theList == NULL)
        return NULL;
    else
    {
        while (theList->next != NULL)
            theList = theList->next;
        return theList;
    }
}

bool isEmpty(Food * theList)
{
    if (theList == NULL)
        return true;
    else
        return false;
}

void printList(Food * theList)
{
    if (theList != NULL)
    {
        while (theList->next != NULL)
        {
            printf("%s (%s):%.2f[%c]",theList->name,theList->foodGroup,theList->calories,theList->type);
            printf("\n");
            theList = theList->next;
        }
        printf("%s (%s):%.2lf[%c]",theList->name,theList->foodGroup,theList->calories,theList->type);
        printf("\n");
    }
}

void destroyList(Food * theList)
{
    Food * nextFood;
    Food * current = theList;
    if (theList != NULL) /* if there is at least one item*/
    {
        while (current != NULL)
        {
            nextFood = current->next; /*if current->next is NULL, so will nextFood*/
            free(current); 
            current = nextFood;
        }
    }
    /* does nothing at all if there wasn't at least one item*/
}
