/*********************
Student Name: Timothy Bratcher      Student Number:0902130
Date: April 1, 2015                 Course Name: CIS2500
I have exclusive control over this submission via my password.
By including this statement in this header comment, I certify that:
    1)I have read and understood the University policy on academic integrity;
    2)I have completed the Computing with Integrity Tutorial on Moodle; and
    3)I have achieved at least 80% in the Computing with Integrity Self Test.
I assert that this work is my own. I have appropriately acknowledged any and all material
(data, images, ideas or words) that I have used, whether directly quoted or paraphrased.
Furthermore, I certify that this assignment was prepared by me specifically for this course.
*********************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "linkedList.h"
#include "diary.h"
int main(int argc, char * argv[])
{
    FILE * file;
    int buffer = 100;
    int q = 0; 
    Food * food;
    Food * theList = NULL;
    Food * temp;
    CalChart * chart;
    char lineIn[buffer];
    //check for valid filename
    if (argc == 2)
    {
        file = fopen(argv[1],"r");
    }
    else
    {
        printf("Wrong number of parameters\n");
        exit(0);
    }
    if (file == NULL)
    {
        printf("Bad file name\n");
        exit(0);
    }
    // read in lines from file, create a Food and sort it
    while (fgets(lineIn,buffer,file) != NULL)
    {
        food = parseLine(lineIn); //calls linkedList.createRecord
        if (food->type == 'h') // sort it by type
        {
            theList = addToFront(theList, food);
        }
        if (food->type == 'j')
        {
            theList = addToBack(theList, food);
        }
    }
    chart = initChart(q);
    calCount(theList, chart);
    //print calorie values
    printf("%.0lf\n", ceil(chart->total));
    if (chart->vegCount != 0)
    	printf("%.2lf\n",(chart->vegfruit/chart->vegCount));
    else
        printf("0.00\n");
    if (chart->meatCount != 0)
        printf("%.2lf\n",(chart->meat/chart->meatCount));
    else
        printf("0.00\n");
    if (chart->dairyCount != 0)
        printf("%.2lf\n",(chart->dairy/chart->dairyCount));
    else
        printf("0.00\n");
    if (chart->grainsCount != 0)
        printf("%.2lf\n",(chart->grains/chart->grainsCount));
    else
        printf("0.00\n");
    if (chart->fatCount != 0)
        printf("%.2lf\n",(chart->fat/chart->fatCount));
    else
        printf("0.00\n");
    printList(theList);
    //free data
    temp = theList;
    do //frees struct internal memory for the whole list
    {
        destroyElement(temp);
        temp = temp->next;
    }while(temp != NULL);
    destroyList(theList);
    free(chart);
    return 0;
}
