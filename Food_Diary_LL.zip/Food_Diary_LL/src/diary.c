/*********************
Student Name: Timothy Bratcher      Student Number:0902130
Date: April 1, 2015                 Course Name: CIS2500
I have exclusive control over this submission via my password.
By including this statement in this header comment, I certify that:
    1)I have read and understood the University policy on academic integrity;
    2)I have completed the Computing with Integrity Tutorial on Moodle; and
    3)I have achieved at least 80% in the Computing with Integrity Self Test.
I assert that this work is my own. I have appropriately acknowledged any and all material
(data, images, ideas or words) that I have used, whether directly quoted or paraphrased.
Furthermore, I certify that this assignment was prepared by me specifically for this course.
*********************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "linkedList.h"
#include "diary.h"

CalChart * initChart(int q)
{
    CalChart * chart = malloc(sizeof(CalChart));
    chart->total = q;
    chart->vegfruit = q;
    chart->meat = q;
    chart->fat = q;
    chart->dairy = q;
    chart->grains = q;
    chart->vegCount = q;
    chart->meatCount = q;
    chart->dairyCount = q;
    chart->grainsCount = q;
    chart->fatCount = q;

    return chart;
}
Food * parseLine(char * lineIn)
{
    char * token;
    char group[26];
    char name[26];
    double cals;
    char type;
    Food * food;
    if (lineIn != NULL)
    {
        token = strtok(lineIn, ","); //parse the file
        strcpy(name, token);
        token = strtok(NULL, ",");
        strcpy(group, token);
        token = strtok(NULL, ",");
        cals = atof(token);
        token = strtok(NULL, "");
        type = token[0];
        food = createRecord(name,group,cals,type);
        return food;
    }
    else
        return NULL;
}

void calCount(Food * theList, CalChart * chart)
{
    do
    {
        chart->total += theList->calories;
        if (strcmp(theList->foodGroup, "vegfruit") == 0)
        {
             chart->vegfruit += theList->calories;
             chart->vegCount++;
        }
        else if (strcmp(theList->foodGroup, "meat") == 0)
        {
            chart->meat += theList->calories;
            chart->meatCount++;
        }
        else if (strcmp(theList->foodGroup, "dairy") == 0)
        {
            chart->dairy += theList->calories;
            chart->dairyCount++;
        }
        else if (strcmp(theList->foodGroup, "grains") == 0)
        {
            chart->grains += theList->calories;
            chart->grainsCount++;
        }
        else if (strcmp(theList->foodGroup, "fat") == 0)
        {
            chart->fat += theList->calories;
            chart->fatCount++;
        }
        theList = theList->next;
    }while (theList != NULL);
}
