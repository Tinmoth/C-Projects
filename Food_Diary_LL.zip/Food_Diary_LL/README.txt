Student Name: Timothy Bratcher
ID: 0902130
Course: CIS2500
Date: April 1, 2015

Filename: foodDiary.c, linkedList.c
Header file: linkedList.h
Input file: user-specified

Compiling:
gcc -Wall -std=c99 src/foodDiary.c src/linkedList.c -Iinclude -o bin/runMe -lm

Running:
./bin/runMe FILENAME

Limitations:
Input file must contain data of the form "string,string,double,char"
Each line of input file must be fewer than 100 characters
