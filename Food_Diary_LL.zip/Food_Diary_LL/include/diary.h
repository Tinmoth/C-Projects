#ifndef _TBRATCHE_DIARYH
#define _TBRATCHE_DIARYH

struct CalChart
{
	double total;
	double vegfruit;
	double meat;
	double dairy;
	double grains;
	double fat;
	int vegCount;
	int meatCount;
	int dairyCount;
	int grainsCount;
	int fatCount;
};

typedef struct CalChart CalChart;
/**********
CalChart
In: None
Out: CalChart * chart
Post: CalChart struct is initiated with all values at 0;
**********/
CalChart * initChart();
/**********
parseLine
In: char *
Out: Food * food
Post: a line of input is used to populate a struct
**********/
Food * parseLine(char * lineIn);
/*********
calCount
In: Food * theList, CalChart * chart)
Out: none
Post: the total and average calories of all Food structs in theList is calculated
*********/
void calCount(Food * theList, CalChart * chart);

#endif
