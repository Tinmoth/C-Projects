/*Student Name: Timothy Bratcher  Student Number:0902130 
Date: January 16, 2015            Course Name: CIS2500
I have exclusive control over this submission via my password.
By including this statement in this header comment, I certify that:
    1)I have read and understood the University policy on academic integrity;
    2)I have completed the Computing with Integrity Tutorial on Moodle; and
    3)I have achieved at least 80% in the Computing with Integrity Self Test.
I assert that this work is my own. I have appropriately acknowledged any and all material
(data, images, ideas or words) that I have used, whether directly quoted or paraphrased.
Furthermore, I certify that this assignment was prepared by me specifically for this course.
*/

#include "obstruct.h"
//main function initializes game board and begins the game
int main()
{
    //variables
    int playNo = 1;
    char command;
    char tip[50] = "i,j,k,l to navigate. m to mark. q to quit";
    char p1[30];
    char p2[30];
    int winCond = 1;
    
    printf("LETS PLAY OBSTRUCTION!");
    printf("\n");
    printf("What is the name of the first player?");
    fgets(p1,30,stdin);
    printf("What is the name of the second player?");
    fgets(p2,30,stdin);

    // ncurses initialization
    initscr();
    cbreak();
    noecho();
    /*Set up the board*/
    move(0,0);
    printw("Welcome to Obstruction");
    move(1,0);
    printw("Ready, %s:",p1);
    displayTip(tip);
    move(4,0);
    drawBorder(8, 8);
    move(5,1);
    refresh();
    command = getch();
    // loop runs until player opts to quit, or there is a winner
    while ((command != 'q')&&(winCond != 0))
    {
        if (playNo == 1)
            playNo = navig(command, playNo, p1, p2, &winCond);
        if (playNo == 2)
            playNo = navig(command, playNo, p2, p1, &winCond);
        if (command != 'q')
            command = getch();
    }
    endwin();
    return 0;
}

/*************
drawBorder: draws the playing board
In: int width, int height
Out: none
Post: the playing board is printed on screen
*************/
void drawBorder(int width, int height)
{
    int x;
    int y;
    getyx(stdscr, y, x);
    for (int i=x; i<width; i++)  //prints top line
    {
        mvaddch(y, i, '-');
    }
    for (int j=y; j<(height+y); j++)   //prints right side
    {
        mvaddch(j, (x+(width-1)), '|');
    }
    for (int k=(width-1); k>=x; k--)  //prints bottom
    {
        mvaddch(((height-1)+y), k, '-');
    }
    for (int m=((height-1)+y); m>(y-1); m--) //prints left side
    {
        mvaddch(m, x, '|');
    }
    refresh();
}

/**************
navig: allows the player to move the cursor around the board, and select a place to mark
In: char command, int playNo, char currentPlayer[], char nextPlayer[], int *winChk
Out: int playNo
Post: if there is a winner, declares the winner
**************/
int navig (char command, int playNo, char currentPlayer[], char nextPlayer[], int *winChk)
{
    int y;
    int x;
    int oldY, oldX;
    char next;
    
    getyx(stdscr, y, x);
    oldY = y;
    oldX = x;
    
    if (command == 'i')
       y--;
    if (command == 'j')
       x--;
    if (command == 'k')
       y++;
    if (command == 'l')
       x++;
    if (command == 'm')   //places a mark only if the space is empty
    {
        if (mvinch(y, x) == ' ')
        {
            mark(y, x, playNo);
            if(scan4win() == 0)
            {
                *winChk = 0;
                displayWinner(currentPlayer);
                move(1,0);
                printw("                                       ");
            }
            if(scan4win() != 0) // switches players if the game isn't over
                playNo = changePlayer(playNo, nextPlayer);
        }
        if(scan4win() == 0)
        {
            *winChk = 0;
        }
    }
    next = mvinch(y, x);
    if ((next == '-')||(next == '|'))   //disallows moving off the board
        move (oldY, oldX);
    refresh();
    return playNo;
}

/*************
changePlayer: switches whose turn it is, and informs the players
In: int playNo, char nextPlayer[]
Out: int playNo
Post: which player's turn it is displayed at top
*************/
int changePlayer(int playNo, char nextPlayer[])
{
    move(1,0);
    if (playNo == 1)
    {
        printw("Your turn, %s",nextPlayer);
        move (4, 1);
        playNo = 2;
        return playNo;
    }
    if (playNo == 2)
    {
        printw("Your Turn, %s",nextPlayer);
        move (4, 1);
        playNo = 1;
        return playNo;
    }
    return playNo;
}

/******************
displayTip: allows tips to be printed on screen
In: char tip[]
Out: none
Post: tip is printed to screen
******************/
void displayTip(char tip[])
{
    int y;
    int x;
    getyx(stdscr, y, x);
    move (2,0);
    printw("%s",tip);
    move (y,x);
}

/***************
displayWinner: displays the game winner
In: char player[]
Out: none
Post: winner's name is printed to screen
***************/
void displayWinner(char player[])
{
    int y;
    int x;
    getyx(stdscr, y, x);
    move (2,0);
    printw("%s WINS!                                                       ",player);
    move (y,x);
}

/*****************
mark: places the player's mark upon the board
In: int y, int x, int playNo
Out: none
Post: board is marked
*****************/
void mark (int y, int x, int playNo)
{
    char sense;
    
    if (playNo == 1)
    {
        mvaddch(y, x, '@');
    }
    if (playNo == 2)
    {
        mvaddch(y, x, '$');
    }
    // marks the surrounding spaces so they cannot be marked
    // but only if they are not a border (to prevent cursor escape)
    sense = mvinch((y-1),(x-1));
    if ((sense != '-')&&(sense != '|'))
        mvaddch((y-1),(x-1),'+');
    sense = mvinch((y-1),x);
    if ((sense != '-')&&(sense != '|'))
        mvaddch((y-1),x,'+');
    sense = mvinch((y-1),(x+1));
    if ((sense != '-')&&(sense != '|'))
        mvaddch((y-1),(x+1),'+');
    sense = mvinch(y,(x-1));
    if ((sense != '-')&&(sense != '|'))
        mvaddch(y,(x-1),'+');
    sense = mvinch(y,(x+1));
    if ((sense != '-')&&(sense != '|'))
        mvaddch(y,(x+1),'+');
    sense = mvinch((y+1),(x-1));
    if ((sense != '-')&&(sense != '|'))
        mvaddch((y+1),(x-1),'+');
    sense = mvinch((y+1),x);
    if ((sense != '-')&&(sense != '|'))
        mvaddch((y+1),x,'+');
    sense = mvinch((y+1),(x+1));
    if ((sense != '-')&&(sense != '|'))
        mvaddch((y+1),(x+1),'+');
}

/*****************
scan4win: checks for a winner
In: none
Out: number of empty spaces
Post: none
*****************/
int scan4win()
{
    int x;
    int y;
    getyx(stdscr,y,x);
    char scan;
    int spaces = 0;
    // board is scanned for empty spaces
    for (int u = 4; u < 12; u++)
    {
        move(u,0);
        for (int p = 0; p < 8; p++)
        {
            move(u,p);
            scan = mvinch(u,p);
            if (scan == ' ')
                spaces++;
        }
    }
    move(y,x);
    return spaces;
} 
