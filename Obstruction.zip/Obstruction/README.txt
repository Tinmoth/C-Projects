Student Name: Timothy Bratcher
ID: 0902130
Course: CIS2500
Date: January 16, 2015

Filename: Obstruct.c
w/ Header File: Obstruct.h

Compiling:
Compile with     
gcc -Wall -pedantic -std=c99 obstruct.c -Iinclude -o filename -lncurses

Running: 
./a.out or ./filename

Limitations:
Player names can only be 29 characters long


Notes:
For aesthetics, colored tiles could be substituted for the '+' marks when 
a player marks a spot. Each player could have a different colored mark, which
would look better than '@' and '$'

For hints, the game could scan the board for an available spot (a ' ') and highlight it to direct the player where to go 
(This could be built into the scan4win function)

For an AI, the second player could be replaced by a rand() function which chooses a random
set of coordinates within the bounds of the game board, and continues to do so
until it finds and available spot. The spot is then marked.

