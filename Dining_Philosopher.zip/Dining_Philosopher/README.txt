Author: Timothy Bratcher
ID: 0902130
Assignment 3

Part 1: Dining Philosophers
compile:
    gcc -Wall -pedantic -pthread -std=c99 dine.c -o dine

run with:
    ./dine arg1 arg2
where arg1 is the number of philosophers and 
        arg2 is the number of times they must eat

Notes:
Simulation uses array of n threads and n mutexes, where n is the number
of philosophers, and each mutex represents a chopstick.
Each philosopher begins in 'thinking' state.
Each enters 'hungry' state and attempts to get the mutex corresponding to their
philosopher ID number, and the one "to the left". I.e. philosopher 2 will attempt to
get mutex 1 and mutex 2. philosopher 4 will attempt to obtain mutex 3 and 4.

After successfully getting the first mutex, philosopher checks to see if the 
other one is available. If not, philosopher unlocks the first and restarts.
Cycle runs until each philosopher/pthread has 'eaten' the specified number of times.

NOTES:
 Because the computer is so fast, without 'sleeps' the program gave the appearance of 
running very linearly. (Eat cycles were nearly instantaneous, so no threads had to wait on others). I instituted a 3-second sleep for eating, and a 5-second
sleep for thinking. 
Additionally, I added more verbage to narrate the waiting process when a thread has to wait for 
a mutex. This makes the algorithm much easier to analyze.


Part 2: Memory Simulator
complile:
	make
or
	gcc -Wall -pedantic -std=c99 -c queue.c
	gcc -Wall -pedantic -std=c99 -c memsim.c
	gcc -Wall -pedantic -std=c99 -o holes main.c memsim.o queue.o
RUN
	./holes <filename>
where arg[1] is the input file with process info for the simulator

NOTE: algorithms were tested individually. It is not uncommon to get very similar or identical averages, particularly if a LARGE process is loaded early, and its removal leaves a space near the beginning of the bitmap that all four algorithms recognize as the ideal hole to place new processes in.

