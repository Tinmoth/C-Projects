#include <stdio.h>       /* Input/Output */
#include <stdlib.h>      /* General Utilities */
#include <unistd.h>      /* Symbolic Constants */
#include <sys/types.h>   /* Primitive System Data Types */
#include <sys/wait.h>    /* Wait for Process Termination */
#include <errno.h>       /* Errors */
#include <strings.h>     /* Strings */
#include <pthread.h>     /* pthreads library */
typedef struct Philo
{
	int total_philos;
	int philo_id;
	int eats;
	pthread_mutex_t * mutes;
}Philo;

void * pickup(void * philo)
{
	Philo * p;
	p = (Philo*)philo;
	int id = p->philo_id;
	int eats = p->eats;
	int eatno = 0;
	int all = p->total_philos;

	while (eatno < eats)
	{
		printf("Philosopher %d is Hungry; Getting 1st chopstick...\n", (id+1));
		pthread_mutex_lock(&p->mutes[id]);
//		printf("Philosopher %d Picked up first chopstick\n",(id+1));
		if (pthread_mutex_trylock(&p->mutes[((id+1)%all)]) == 0)
		{
			/*successfully got second chopstick*/
//			printf("Philosopher %d picked up second chopstick\n",(id+1));
			printf("Philosopher %d is Eating\n", (id+1));
			eatno = eatno + 1;
			sleep(3);
			/*release both locks*/
			pthread_mutex_unlock(&p->mutes[((id+1)%all)]);
			pthread_mutex_unlock(&p->mutes[id]);
			if (eatno == eats)
			{
				printf("Philosopher %d is Satisfied\n",(id+1));
			}
			else
				printf("Philosopher %d is Thinking\n",(id+1));
			sleep(5);
		}
		else
		{	
			/* didn't get chopstick*/
			printf("Philosopher %d: 2nd chopstick unavailable; Release 1st chopstick\n",(id+1));
			pthread_mutex_unlock(&p->mutes[id]);
			sleep(3);
		}
	}
	pthread_exit(NULL);
}

int main(int argc, char*argv[])
{

	int num_philo;
	int num_eats;
	int i,err;
	pthread_t * threads;
	Philo * philos;
	pthread_mutex_t * mutes;

	if (argc < 3)
	{
		printf("Not enough parameters\n");
		exit(0);
	}
	/* get number of philosophers, times eating*/
	num_philo = atoi(argv[1]);
	num_eats = atoi(argv[2]);
	/* create philosophers, a thead for each, and initial values for each*/
	/* create shared mutexes */
	threads = malloc(sizeof(pthread_t)*num_philo);
	philos = malloc(sizeof(Philo)*num_philo);
	mutes = malloc(sizeof(pthread_mutex_t)*num_philo);
	for (i = 0; i < num_philo; i++)
	{
		philos[i].philo_id = i;
		philos[i].eats = num_eats;
		philos[i].mutes = mutes;
		philos[i].total_philos = num_philo;
		printf("Philosopher %d is Thinking\n",(i+1));
	}
	/*begin execution of threads*/	
	for (i = 0; i < num_philo; i++)
	{
		err = pthread_create(&threads[i], NULL, pickup, (void*)&philos[i]);
    	if (err)
    	{
        	printf("ERROR; return code from pthread_create() is %d\n", err);
        	exit(-1);
    	}
    }
    for (i = 0; i < num_philo; i++)
    {
    	pthread_join(threads[i], NULL);
    }
    /* free allocated memory */
	free(mutes);
	free(philos);
	free(threads);
	pthread_exit(NULL);
}
