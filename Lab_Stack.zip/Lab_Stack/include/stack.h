#ifndef _TBRATCHE_STACKH
#define _TBRATCHE_STACKH

#include "linkedList.h"
#include <stdlib.h>
#include <stdio.h>

typedef struct Stack
{
    listNode * listHead;
}Stack;
/*
createStack
purpose: creates a new stack with a listNode pointing to the next item on the stack
pre: none
post: a new Stack is created
*/
Stack * createStack();
/*
push
purpose: adds an element to the stack
pre: stack is initialized (can be empty)
post: stack has one more item on top
*/
void push(Stack * stack, listNode * newNode);
/*
pop
purpose: removes the top item off the stack
pre: stack is not empty
post: the stack is one item shorter
*/
void pop(Stack * stack);
/*
peek
purpose: retrieves the top element on the stack without removing it
pre: stack is not empty
post: none
*/
listNode * peek(Stack * stack);
/*
destroy
purpose: destroys stack (removes all elements, frees memory)
pre: none
post: stack is empty, memory is freed
*/
void destroyStack(Stack * stack);
#endif
