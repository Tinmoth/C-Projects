Name: Timothy Bratcher
Student: 0902130
Lab 03, CIS2520

Filename: linkedList.c, stack.c, stackTest.c
Header files: linkedList.h, stack.h

Compiling:
gcc -Wall -ansi src/linkedList.c src/stack.c src/stackTest.c -Iinclude -o /bin/runMe

Running:
./bin/runMe

Testing:
1. program was tested using negative and positive numbers
2. nodes are successfully created, pushed, and popped
3. Tested operations on NULL stack: no seg fault (operation fails)

