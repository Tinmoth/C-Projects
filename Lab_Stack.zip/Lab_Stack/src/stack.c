#include "stack.h"
#include "linkedList.h"

Stack * createStack()
{
    Stack * stack = malloc(sizeof(Stack)*1);
    stack->listHead = createList();
    return stack;
}
void push(Stack * stack, listNode * newNode)
{
    if (stack != NULL)
    {
        addToFront(stack->listHead, newNode);
    } /*if stack is not initialized, does nothing */
}
void pop(Stack * stack)
{
    if (stack != NULL)
    {
        removeFromFront(stack->listHead);
    } /* if stack is empty does nothing */
}
listNode * peek(Stack * stack)
{
    listNode * listPeek = stack->listHead->next;
    return listPeek;
}
void destroyStack(Stack * stack)
{
    if (stack != NULL)
    {
        destroyList(stack->listHead);
    }
    free(stack->listHead);
    stack->listHead = NULL;
}/* stack memory must be freed outside */