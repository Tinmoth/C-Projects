#ifndef _TBRATCHE_MEMSIMH
#define _TBRATCHE_MEMSIMH


#include "queue.h"

int count_holes(int * bitmap);
int measure_hole(int * bitmap, int sindex);
void get_procs(FILE * infile, Queue * inqueue);
void best_fit(int * bitmap, Queue * pending, Queue * placed);
void worst_fit(int * bitmap, Queue * pending, Queue * placed);
void first_fit(int * bitmap, Queue * pending, Queue * placed);
void next_fit(int * bitmap, Queue * pending, Queue * placed);

#endif
