/* memsim.c
Author Timothy Bratcher
ID: 0902130
CIS 3110; March 25, 2016
*/
#include "queue.h"
#include "memsim.h"

int scan_for_big(int * bitmap, int * index)
{
	int k = 0;
	int end = 0;
	int big = 0;
	int temp;

	while (end != 1)
	{
		while (bitmap[k] != 0)
		{
			k = k + 1;
			if (k == 128)
				return big;
		}
		temp = measure_hole(bitmap, k);
		if (temp > big)
		{
			big = temp;
			*index = k;
		}
		k = k + temp;
		if (k == 128)
			end = 1;
	}
	return big;
}
int scan_for_best(int size, int * bitmap, int * index)
{
	int bindex;
	int end = 0;
	int k = 0;
	int best;
	int temp;
	/*first, get biggest hole and index*/
	best = scan_for_big(bitmap, &bindex);
	while (end != 1)
	{
		while (bitmap[k] ==1)
		{
			k = k + 1;
		}
		if (k == 128)
		{
			bindex = 0;
			best = 0;
			*index = bindex;
			return best;
		}
		temp = measure_hole(bitmap, k);
		if ((temp >= size) && (temp < best))
		{
			best = temp;
			bindex = k;
		}
		k = k + temp;
		if (k == 128)
		{
			end = 1;
		}
	}
	*index = bindex;
	return best;
}
int meas_mem(int * bitmap)
{
	int m = 0;
	int i;
	for (i = 0; i < 128; i++)
	{
		if (bitmap[i] == 1)
			m = m + 1;
	}
	return m;
}
int count_holes(int * bitmap)
{
	int holes = 0;
	int k = 0;
	while (k < 128)
	{
		while (bitmap[k] == 1)
		{
			k = k + 1;
			if (k == 128)
				return holes;
		}//found a hole
		holes = holes + 1;
		while (bitmap[k] == 0)
		{
			k = k + 1;
			if (k == 128)
				return holes;
		}// hole ended	
	}
	return holes;
}
/* returns size of hole at start index specified */
int measure_hole(int * bitmap, int sindex)
{
	int size = 0;
	while (bitmap[sindex] == 0)
	{
		size = size + 1;
		sindex = sindex + 1;
		if (sindex == 128)
			return size;
	}
	return size;
}
void get_procs(FILE * infile, Queue * inqueue)
{
	char id[2];
	int proc_size;
	Node * newn;

/* have to do this 4 times */
	while(fscanf(infile, "%s%d",id, &proc_size) == 2)
    {
//       	printf("%s %d\n",id, proc_size);
       	newn = malloc(sizeof(Node)*1);
       	newn->id = id[0];
       	newn->size = proc_size;
       	newn->sindex = 0;
       	newn->findex = 0;
       	newn->swapped = 0;

       	add(newn, inqueue);
    }
    fclose(infile);
}
// each algorithm has its own way of finding holes. Universal methods to count holes and measure holes available
void best_fit(int * bitmap, Queue * pending, Queue * placed)
{
	Node * temp;
	int bestloads = 0;
	Node * remTemp;
	int set = 0;
	int i;
	int tot_procs = 0;
	int tot_holes = 0;
	int memusage = 0;
	int cum_memusage = 0;
	int cur_holes;
	double avg_holes;
	double avg_procs;
	int index;
	int best;
	printf("Running Best Fit:\n");
	while (pending->size != 0)
	{
		temp = rem(pending);
		set = 0;
		while (set != 1)
		{
			best = scan_for_best(temp->size, bitmap, &index);
			if (best >= temp->size)
			{
				temp->sindex = index;
				temp->findex = temp->sindex + temp->size;
				for (i = temp->sindex; i < temp->findex; i++)
				{
					bitmap[i] = 1;
				}
				add(temp, placed);
				bestloads = bestloads + 1;
				set = 1;
				cur_holes = count_holes(bitmap);
				tot_holes = tot_holes + cur_holes;
				tot_procs = tot_procs + placed->size;
				memusage = (meas_mem(bitmap) * 100) / 128;
				cum_memusage = cum_memusage + memusage;
				printf("pid loaded, #processes = %d, #holes = %d, %%memusage = %d, cumulative %%mem = %d\n",placed->size, cur_holes, memusage, (cum_memusage / bestloads)); 
	
			}
			else
			{
				remTemp = rem(placed);
				for (i = remTemp->sindex; i < remTemp->findex; i++)
				{
					bitmap[i] = 0;
				}
				remTemp->swapped = remTemp->swapped + 1;
				if (remTemp->swapped == 3)
				{
					free(remTemp);
				}
				else
				{
					remTemp->sindex = 0;
					remTemp->findex = 0;
					add(remTemp, pending);
				}	
			}
		}//end while set != 1
	}
	avg_procs = (double)tot_procs / (double)bestloads;
	avg_holes = (double)tot_holes / (double)bestloads;
	printf("Total loads = %d, average #processes = %lf, average #holes = %lf, cumulative %%mem = %d\n",bestloads, avg_procs, avg_holes, (cum_memusage / bestloads));
}
void worst_fit(int * bitmap, Queue * pending, Queue * placed)
{
	int worstloads = 0;
	Node * temp;
	Node * remTemp;
	int set = 0;
	int i;
	int tot_procs = 0;
	int tot_holes = 0;
	int memusage = 0;
	int cum_memusage = 0;
	int cur_holes;
	double avg_holes;
	double avg_procs;
	int big;
	int index;

	printf("Running Worst Fit:\n");
	while (pending->size != 0)
	{
		temp = rem(pending);
		set = 0;
		while (set != 1)
		{
			big = scan_for_big(bitmap, &index);
//			printf("biggest hole is at: %d\n",index);
			if (temp->size <= big)
			{
				temp->sindex = index;
				temp->findex = temp->sindex + temp->size;
				for (i = temp->sindex; i < temp->findex; i++)
				{
					bitmap[i] = 1;
				}
				add(temp, placed);
				worstloads = worstloads + 1;
				set = 1;
				cur_holes = count_holes(bitmap);
				tot_holes = tot_holes + cur_holes;
				tot_procs = tot_procs + placed->size;
				memusage = (meas_mem(bitmap) * 100) / 128;
				cum_memusage = cum_memusage + memusage;
				printf("pid loaded, #processes = %d, #holes = %d, %%memusage = %d, cumulative %%mem = %d\n",placed->size, cur_holes, memusage, (cum_memusage / worstloads)); 
			}	
			else
			{
				remTemp = rem(placed);
				for (i = remTemp->sindex; i < remTemp->findex; i++)
				{
					bitmap[i] = 0;
				}
				remTemp->swapped = remTemp->swapped + 1;
				if (remTemp->swapped == 3)
				{
					free(remTemp);
				}
				else
				{
					remTemp->sindex = 0;
					remTemp->findex = 0;
					add(remTemp, pending);
				}	
			}
		}
	}
	avg_procs = (double)tot_procs / (double)worstloads;
	avg_holes = (double)tot_holes / (double)worstloads;
	printf("Total loads = %d, average #processes = %lf, average #holes = %lf, cumulative %%mem = %d\n",worstloads, avg_procs, avg_holes, (cum_memusage / worstloads));
}
void first_fit(int * bitmap, Queue * pending, Queue * placed)
{
	int firstloads = 0;
	Node * temp;
	Node * remTemp;
	int set = 0;
	int k = 0;
	int i;
	int hole;
	int tot_procs = 0;
	int tot_holes = 0;
	int memusage = 0;
	int cum_memusage = 0;
	int cur_holes;
	double avg_holes;
	double avg_procs;

	printf("Running First Fit:\n");
	while (pending->size != 0)
	{
		k = 0;
		set = 0;
		temp = rem(pending);
//		printf("Removed a node from pending, ID: %c\n",temp->id);
		while (set != 1)
		{
			while (k != 128)
			{
				while (bitmap[k] != 0)
				{
					k = k + 1;
					if (k == 128)
					{
						printf("End of bitmap\n");
						break;
					}
				}
//				printf("Found hole at: %d\n",k);
				if (k != 128)
				{
					hole = measure_hole(bitmap, k);
//					printf("Found hole size: %d\n",hole);
//					printf("Size needed is %d\n",temp->size);
					if (temp->size <= hole)
					{
						temp->sindex = k;
						temp->findex = temp->sindex + temp->size;
						for (i = temp->sindex; i < temp->findex; i++)
						{
							bitmap[i] = 1;
						}
//						printf("Process %c fits in hole.\n",temp->id);
						add(temp, placed);
//						printf("total placed: %d\n",placed->size);
						firstloads = firstloads + 1;
						set = 1;
//						for (i = 0; i < 128; i++)
//							printf("%d",bitmap[i]);
//						printf("\n");
						cur_holes = count_holes(bitmap);
						tot_holes = tot_holes + cur_holes;
						tot_procs = tot_procs + placed->size;
						memusage = (meas_mem(bitmap) * 100) / 128;
						cum_memusage = cum_memusage + memusage;
						printf("pid loaded, #processes = %d, #holes = %d, %%memusage = %d, cumulative %%mem = %d\n",placed->size, cur_holes, memusage, (cum_memusage / firstloads)); 
						k = 0;
						break;
					}
					else
					{
						k = k + hole;
					}
				}
			}
			if (k == 128)		//get here via break
			{
				remTemp = rem(placed);
//				printf("removing process %c from Placed\n",remTemp->id);
				for (i = remTemp->sindex; i < remTemp->findex; i++)
				{
					bitmap[i] = 0;
				}
				remTemp->swapped = remTemp->swapped + 1;
				if (remTemp->swapped == 3)
				{
//					printf("Process %c is Finished\n",remTemp->id);
					free(remTemp);
				}
				else
				{
					remTemp->sindex = 0;
					remTemp->findex = 0;
					add(remTemp, pending);
				}
				k = 0;
			}
		}
	}
	avg_procs = (double)tot_procs / (double)firstloads;
	avg_holes = (double)tot_holes / (double)firstloads;
	printf("Total loads = %d, average #processes = %lf, average #holes = %lf, cumulative %%mem = %d\n",firstloads, avg_procs, avg_holes, (cum_memusage / firstloads));
}
void next_fit(int * bitmap, Queue * pending, Queue * placed)
{
	int cur_index = 0;
	int nextloads = 0;
	Node * temp;
	Node * remTemp;
	int set = 0;
	int k = 0;
	int i;
	int hole;
	int tot_procs = 0;
	int tot_holes = 0;
	int memusage = 0;
	int cum_memusage = 0;
	int cur_holes;
	double avg_holes;
	double avg_procs;

	printf("Running Next Fit:\n");
	while (pending->size != 0)
	{
		k = cur_index;
		set = 0;
		temp = rem(pending);
//		printf("Removed a node from pending, ID: %c\n",temp->id);
		while (set != 1)
		{
			while (k != (cur_index - 1))
			{
				if (k == 128)
					k = 0;
				while (bitmap[k] != 0)
				{	
					if (k == 128)
						k = 0;

					if (k == 127)
						k = 0;
					else
						k = k + 1;
					if (k == (cur_index - 1))
					{
						break;
					}
				}
				if (k != (cur_index - 1))
				{

					hole = measure_hole(bitmap, k);
//					printf("found hole at %d size %d\n",k,hole);
					if (temp->size <= hole)
					{
						temp->sindex = k;
						temp->findex = temp->sindex + temp->size;
						cur_index = temp->findex;
						for (i = temp->sindex; i < temp->findex; i++)
						{
							bitmap[i] = 1;
						}
						add(temp, placed);
						nextloads = nextloads + 1;
						set = 1;
						cur_holes = count_holes(bitmap);
						tot_holes = tot_holes + cur_holes;
						tot_procs = tot_procs + placed->size;
						memusage = (meas_mem(bitmap) * 100) / 128;
						cum_memusage = cum_memusage + memusage;
						printf("pid loaded, #processes = %d, #holes = %d, %%memusage = %d, cumulative %%mem = %d\n",placed->size, cur_holes, memusage, (cum_memusage / nextloads)); 
						k = 0;
						break;
					}
					else
					{
						k = k + hole;
					}
				}
			}
			if (k == (cur_index - 1))		//get here via break
			{

				remTemp = rem(placed);
//				printf("removing %c\n",remTemp->id);
				for (i = remTemp->sindex; i < remTemp->findex; i++)
				{
					bitmap[i] = 0;
				}
				remTemp->swapped = remTemp->swapped + 1;
				if (remTemp->swapped == 3)
				{
//					printf("Process %c is Finished\n",remTemp->id);
					free(remTemp);
				}
				else
				{
					remTemp->sindex = 0;
					remTemp->findex = 0;
					add(remTemp, pending);
				}
				k = 0;
			}
		}// end set
	}// end queue
	avg_procs = (double)tot_procs / (double)nextloads;
	avg_holes = (double)tot_holes / (double)nextloads;
	printf("Total loads = %d, average #processes = %lf, average #holes = %lf, cumulative %%mem = %d\n",nextloads, avg_procs, avg_holes, (cum_memusage / nextloads));
}
