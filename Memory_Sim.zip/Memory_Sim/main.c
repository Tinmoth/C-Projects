/* main.c
Author Timothy Bratcher
ID: 0902130
CIS 3110; March 25, 2016

Simulates memory management using FOUR different algorithms:
	First Fit
	Best Fit
	Next Fit
	Worst Fit
*/
#include "memsim.h"
#include "queue.h"

int main(int argc, char * * argv)
{
	Queue * pending[4];
	Queue * placed[4];
	int bitmap[4][128];
	int j,k;
	FILE * infile;
	//duplicate all data 4 times, one for each algorithm
	for (k = 0; k < 4; k++)
	{
		for (j = 0; j < 128; j++)
		{
			bitmap[k][j] = 0;
		}
	}

	if (argc == 2)
        infile = fopen(argv[1],"r");
    else
    {
        printf("Wrong number of parameters\n");
        exit(0);
    }
    if (infile == NULL)
    {
        printf("Bad file name\n");
        exit(0);
    }
    for (j = 0; j < 4; j++)
    {
    	pending[j] = init();
    	placed[j] = init();
    }
    //read in procs, 4 times
 	get_procs(infile, pending[0]);
 	infile = fopen(argv[1],"r");
 	get_procs(infile, pending[1]);
 	infile = fopen(argv[1],"r");
 	get_procs(infile, pending[2]);
 	infile = fopen(argv[1],"r");
 	get_procs(infile, pending[3]);

 	first_fit(bitmap[0], pending[0], placed[0]);
 	best_fit(bitmap[2], pending[2], placed[2]);
 	next_fit(bitmap[3], pending[3], placed[3]);
 	worst_fit(bitmap[1], pending[1], placed[1]);
 	
 	for (k = 0; k < 4; k++)
 	{
 		destroy(placed[k]);
 	}

 //	printf("size: %d\n first ID:%c\n first size:%d\n",pending->size, pending->first->id, pending->first->size);   
	return 0;

}
