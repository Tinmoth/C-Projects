#include "queue.h"

Queue * init()
{
	Queue * newq = malloc(sizeof(Queue)*1);
	newq->size = 0;
	newq->first = NULL;
	newq->last = NULL;

	return newq;
}
void add(Node * node, Queue * queue)
{
	if (queue->size == 0)
	{
		queue->first = node;
		queue->last = node;
	}
	else
	{
		queue->last->next = node;
		queue->last = node;
	}
	queue->size = queue->size + 1;
}
Node * rem(Queue * queue)
{
	if (queue->size != 0)
	{
		Node * remNode;
		remNode = queue->first;
		queue->first = queue->first->next;
		queue->size = queue->size - 1;
		return remNode;
	}
	else
		printf("Empty Queue\n");
	return 0;
}
void destroy(Queue * queue)
{
	Node * tempNode;
	int i;
	for (i = 0; i < queue->size; i++)
	{
		tempNode = queue->first;
		queue->first = queue->first->next;
		free(tempNode);
	}
	free(queue);
}
/* returns number of holes */
