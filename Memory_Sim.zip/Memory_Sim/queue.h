#ifndef _TBRATCHE_QUEUEH
#define _TBRATCHE_QUEUEH

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Node
{
	char id;
	int size;
	int swapped;
	int sindex;
	int findex;
	struct Node * next;
}Node;
typedef struct Queue
{
	int size;
	struct Node * first;
	struct Node * last;
}Queue;

Queue * init();
void add(Node * node, Queue * queue);
Node * rem(Queue * queue);
void destroy();

#endif
