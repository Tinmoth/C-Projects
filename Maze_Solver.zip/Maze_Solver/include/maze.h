/* Name: Timothy Bratcher
   Student: 0902130
*/
#ifndef _TBRATCHE_MAZEH
#define _TBRATCHE_MAZEH

#include "stack.h"
#include "linkedList.h"
#include <stdio.h>
#include <stdlib.h>

/*
open
purpose: opens a file. exits if filename is not valid
pre:none
post:file is opened
*/
FILE * open(char * filename);
/*
moveRight
purpose: moves the maze navigator to the right
pre:stack is initialized with at least a starting position
post:a new node is added to the stack
*/
listNode * moveRight(listNode * stackTop);
/*
moveLeft
purpose: moves maze navigation to the left
pre: stack is initialized
post: new node is added to stack
*/
listNode * moveLeft(listNode * stackTop);
/*
moveUp
purpose: moves maze navigation upward
pre: stack is initialized
post: new node is added to stack
*/
listNode * moveUp(listNode * stackTop);
/*
moveDown
purpose: moves maze navigation downward
pre: stack is initilialized
post: new node is added to stack
*/
listNode * moveDown(listNode * stackTop);
/*
advance
purpose: determines which direction to navigate
pre: starting position is established
post: if there is an open space, a node is added via function call. 
      otherwise, a node is popped off the stack (backtrack)
*/
void advance(Stack * stack, char * * maze, listNode * stackTop, int mazeY, int mazeX);
/*
findS
purpose: finds the starting point of the maze
pre: maze is initialized
post: returns the starting coordinates
*/
void findS(Stack * stack, char * * maze, int mazeY, int mazeX);
/*
printSolved
purpose: prints the solution to the maze
pre: none
post: maze is printed
*/
void printSolved(Stack * stack, char * * maze, int mazeY, int mazeX);

#endif
