/* Name: Timothy Bratcher
   Student: 0902130
*/
/*
This .h file's pseudocode was provided in the Lab instructions
*/

#ifndef _TBRATCHE_LINKEDLISTH
#define _TBRATCHE_LINKEDLISTH

#include <stdlib.h>
#include <stdio.h>

typedef struct listNode
{
    int nodeValue;    
    int x;
    int y;
    struct listNode * next;
}listNode;
/*
createList
purpose: creates a new list with a dummy node as head
pre: None
post: a new listNode is created
*/ 
listNode * createList();
/*
addFront
purpose: adds a node to the front of a linked list
pre: an initialized listNode is passed as a parameter
post: a listNode is added at the front of the list
*/
void addToFront(listNode * head, listNode * newNode);
/*
printList
purpose: prints out the formatted value of all nodes in the list
pre: a populated list is passed in (at least 1 non-dummy node)
post: none
*/
void printList(listNode * head);
/*
initNode
purpose: creates a new, unattached listNode
pre: a valid integer is passed in
post: a new listNode is created
*/
listNode * initNode(int xVal, int yVal);
/*
getValue
purpose: retrieves value of lead node
pre: the list is initiated
post: none
*/
int getValue(listNode * head);
/*
length
purpose: returns the length of the list
pre: list is initialized
post: none
*/
int getLength(listNode * head);
/*
removeFromFront
purpose: removes the front node
pre: list is initialized
post: a node is removed and memory is freed
*/
void removeFromFront(listNode * head);
/*
destroyList
pre: list is initialized
post: list is destroyed, memory freed
*/
void destroyList(listNode * head);

#endif


