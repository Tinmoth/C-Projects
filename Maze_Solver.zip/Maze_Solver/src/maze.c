/* Name: Timothy Bratcher
   Student: 0902130
*/
#include <stdio.h>
#include <stdlib.h>
#include "maze.h"
#include "stack.h"
#include "linkedList.h"
#include "string.h"

FILE * open(char * filename)
{
    FILE * file = fopen(filename, "r");
    if (file == NULL)
    {
        printf("Bad file name\n");
        exit(0);
    }
    return file;
}

listNode * moveRight(listNode * stackTop)
{
    listNode * newNode = initNode((stackTop->x + 1),stackTop->y);
    return newNode;
}
listNode * moveLeft(listNode * stackTop)
{
    listNode * newNode = initNode((stackTop->x - 1),stackTop->y);
    return newNode;
}
listNode * moveUp(listNode * stackTop)
{
    listNode * newNode = initNode(stackTop->x,(stackTop->y - 1));
    return newNode;
}
listNode * moveDown(listNode * stackTop)
{
    listNode * newNode = initNode(stackTop->x,(stackTop->y + 1));
    return newNode;
}

void advance(Stack * stack, char * * maze, listNode * stackTop, int mazeY, int mazeX)
{
    maze[stackTop->y][stackTop->x] = 'X'; /*mark the current location as visited*/
    if ((maze[stackTop->y+1][stackTop->x] == 'F')||
        (maze[stackTop->y-1][stackTop->x] == 'F')||
        (maze[stackTop->y][stackTop->x+1] == 'F')||
        (maze[stackTop->y][stackTop->x-1] == 'F'))
    {
        if (maze[stackTop->y+1][stackTop->x] == 'F')
        {
            push(stack, moveDown(stackTop));
        }
        else if (maze[stackTop->y-1][stackTop->x] == 'F')
        {
            push(stack, moveUp(stackTop));
        }
        else if (maze[stackTop->y][stackTop->x+1] == 'F')
        {
            push(stack, moveRight(stackTop));
        }
        else if (maze[stackTop->y][stackTop->x-1] == 'F')
        {
            push(stack, moveLeft(stackTop));
        }
    } 
    else if (stackTop->x == 0)
    {
	push(stack, moveRight(stackTop));
    }/* S is on the left side. only look right*/
    else if (stackTop->y == 0)
    {
        push(stack, moveDown(stackTop));
    }/* S is on the top. only look down*/
    else if (stackTop->y == (mazeY-1))
    {
	push(stack, moveUp(stackTop));
    }/* S is on the bottom. only look up*/
    else if (stackTop->x == (mazeX-1))
    {
	push(stack, moveLeft(stackTop));
    }/* S is on the right side. only look left*/
    else
    {
        if (maze[stackTop->y][stackTop->x+1] == ' ')/*look right*/
        {
            push(stack, moveRight(stackTop));
        }
        else if (maze[stackTop->y-1][stackTop->x] == ' ')/*look up*/
        {
            push(stack, moveUp(stackTop));
        }
        else if (maze[stackTop->y][stackTop->x-1] == ' ')/*look left*/
        {
            push(stack, moveLeft(stackTop));
        }
        else if (maze[stackTop->y+1][stackTop->x] == ' ')/*look down*/
        {
            push(stack, moveDown(stackTop));
        }
        else
        {
            pop(stack);
        }
    }/* S is somewhere in the middle. look everywhere */
}

void findS(Stack * stack, char * * maze, int mazeY, int mazeX)
{
    /* assumes only one 'S' on maze */
    int i;
    int j;
    listNode * start;
    for (i = 0; i < mazeY; i++)
    {
        for (j = 0; j < mazeX; j++)
        {
            if (maze[i][j] == 'S')
            {
                start = initNode(j,i);
                push(stack, start);
            }
        }
    }
}
void printSolved(Stack * stack, char * * maze, int mazeY, int mazeX)
{
    int i;
    int j;
    /* first, draw solution on maze */
    while (stack->listHead->next != NULL)
    {
        listNode * top = peek(stack);
        maze[top->y][top->x] = '%';
        pop(stack);
    }
    /* next, print the maze */
    for (i = 0; i < mazeY; i++)
    {
        for (j = 0; j < mazeX; j++)
        {
            printf("%c",maze[i][j]);
        }
        printf("\n");
    }
}
