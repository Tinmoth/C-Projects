/* Name: Timothy Bratcher
   Student: 0902130
*/
#include "stack.h"

int main(void)
{
    /* same test data as lab2 */
    int i = 0;
    listNode * newNode;
    listNode * peeked;
    Stack * nullStack = NULL;
    int testData[5] = {-8,0,4,-7,3};
    Stack * stack = createStack();

/* Initiate test of push(), peek() */
    printf("Testing push(), peek()...\n");
    for (i = 0; i < 5; i++)
    {
        newNode = initNode(testData[i]);
        push(stack, newNode);
        peeked = peek(stack);
        if (peeked->nodeValue == testData[i])
        {
            printf("Passed; Top List Item: %d\n",peeked->nodeValue);
        }
        else
        {
            printf("Failed\n");
        }
    }
/* Initiate test of pop() */
    printf("Testing pop()...\nCurrent top item: %d\n", peeked->nodeValue);
    pop(stack);
    peeked = peek(stack);
    printf("Popping... new top item: %d\n", peeked->nodeValue);
/* Initiate test of destroyStack() */
    printf("Testing destroyStack()...\n");
    destroyStack(stack);
    if (stack->listHead == NULL)
    {
        printf("Passed\n");
    }
    else
    {
        printf("Failed. Stack top is %d\n", stack->listHead->nodeValue);
    }
    free(stack);
/* Initiate test of operations on NULL stack */
    printf("Testing pop(), push() on NULL stack...");
    newNode = initNode(testData[4]);
    pop(nullStack);
    push(nullStack, newNode);
    printf("Passed; no seg fault\n");
    free(newNode);
    return 0;
}