/*  Name: Timothy Bratcher
    Student: 0902130
*/
#include "linkedList.h"

listNode * createList ()
{
    listNode * head = malloc(sizeof(listNode)*1);
    head->nodeValue = 0;
    head->next = NULL;
    return head;
}
void addToFront(listNode * head, listNode * newNode)
{
    newNode->next = head->next;
    head->next = newNode;
    head->x++;
}

void printList(listNode * head)
{
	int i;
	listNode * current = head->next;
	for (i = 0; i < getLength(head); i++)
	{
	    printf("%d\n",current->nodeValue);
	    current = current->next;
	}
}
listNode * initNode(int xVal, int yVal)
{
    listNode * newNode = malloc(sizeof(listNode)*1);
    newNode->x = xVal;
    newNode->y = yVal;
    newNode->next = NULL;
    return newNode;
}
int getValue(listNode * head)
{
    int j = head->next->nodeValue;
    return j;
}
int getLength(listNode * head)
{
    int k = head->nodeValue;
    return k;
}
void removeFromFront(listNode * head)
{
    if (head != NULL)
    {
        if (head->next != NULL)
        {
            listNode * current = head->next;
            head->next = current->next;
            head->nodeValue--;
            free(current);
        }
    }    /* does nothing if list is empty */
}
void destroyList(listNode * head)
{
    if (head != NULL)
    {
        while (head->next != NULL)
        {
            removeFromFront(head);
        }
    }
}/* memory for head must be freed elsewhere */
