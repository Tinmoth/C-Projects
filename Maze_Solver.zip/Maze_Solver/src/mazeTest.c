/* Name: Timothy Bratcher
   Student: 0902130
*/
#include "stack.h"
#include "linkedList.h"
#include "maze.h"
#include <string.h>

int main(int argc, char * argv[])
{
    Stack * stack;
    int mazeY;
    int mazeX;
/*int test;
*/    FILE * inFile;
    int buffer = 100;
    char * * maze = malloc(sizeof(char*)*100);
    char * * mazeCopy = malloc(sizeof(char*)*100);
    char inString[buffer];
    int lineIndex = 0;
    int i;
    if (argc == 2)
    {
        inFile = open(argv[1]);
    }
    else
    {
        printf("Wrong number of parameters\n");
        exit(0);
    }
    /* read in the maze, store to 2d array */
    while (fgets(inString,buffer,inFile) != NULL)
    {
        maze[lineIndex] = malloc(sizeof(char)*(strlen(inString)+1));
        mazeCopy[lineIndex] = malloc(sizeof(char)*(strlen(inString)+1));
        strcpy(maze[lineIndex], inString);
        strcpy(mazeCopy[lineIndex], inString);
        lineIndex++;
    }
    mazeX = strlen(maze[0]) - 1;
    mazeY = lineIndex;
    /* begin stack usage*/
    stack = createStack();
    findS(stack, maze, mazeY, mazeX); /* finds Start of maze*/
    while (maze[peek(stack)->y][peek(stack)->x] != 'F')
    {
        advance(stack, maze, peek(stack), mazeY, mazeX);

    }/*finds end of maze*/

    printSolved(stack, mazeCopy, mazeY, mazeX); 
    /* free all memory */
    destroyStack(stack);
    free(stack);
    for (i = 0; i < lineIndex; i++)
    {
        free(maze[i]);
        free(mazeCopy[i]);
    }
    free(maze);
    free(mazeCopy);
    return(0);
}
