/* Student Name: Timothy Bratcher         Student Number:0902130
Date: February 13, 2015                   Course Name: CIS2500
I have exclusive control over this submission via my password.
By including this statement in this header comment, I certify that:
    1)I have read and understood the University policy on academic integrity;
    2)I have completed the Computing with Integrity Tutorial on Moodle; and
    3)I have achieved at least 80% in the Computing with Integrity Self Test.
I assert that this work is my own. I have appropriately acknlowledged any and all material
(data, images, ideas, or words) that I have used, whether directly quoted or paraphrased.
Furthermore, I certify that this assignment was prepared by me specifically for this course.
*/
#include "logoInt.h"

// functions go here
/***************
drawScreen: draws the logo interface
In: none
Out: none
Post: interface is drawn
****************/
void drawScreen(void)
{
    // prints Logo window for Turtle
    for (int i = 0; i < 54; i++)
    {
        mvaddch(0,i,'L');
        mvaddch(28,i,'L');
    }
    for (int j = 0; j < 28; j++)
    {
        mvaddch(j,0,'L');
        mvaddch(j,54,'L');
    }
    refresh();
    //prints error box
    for (int k = 0; k < 54; k++)
    {
        mvaddch(30, k, 'E');
        mvaddch(32, k, 'E');
    }
    for (int m = 30; m < 33; m++)
    {
        mvaddch(m, 0, 'E');
        mvaddch(m, 54, 'E');
    }
    // prints command box
    for (int n = 0; n < 54; n++)
    {
        mvaddch(33, n, 'C');
        mvaddch(36, n, 'C');
    }
    for (int o = 33; o < 37; o++)
    {
        mvaddch(o, 0, 'C');
        mvaddch(o, 54, 'C');
    }
}
/***********
moveTurtle: moves the turtle to new coordinates
In: Turtle * turt, int newY, int newX
Out: none
Post: moves Turtle to new location
***********/
void moveTurtle(Turtle *turt, int newY, int newX)
{
    // places and redraws the Turtle
    turt->y = newY;
    turt->x = newX;
    mvaddch(turt->y, turt->x, 'O');
    refresh();
}
/*************
turtleHome: moves the Turtle to the origin (center of interface window)
In: Turtle * turt
Out: none
Post: Turtle is moved to the center
*************/
void turtleHome(Turtle *turt)
{
    turt->y = 13;
    turt->x = 26;
    turt->direct = 1;
    mvaddch(turt->y, turt->x, 'O');
    refresh();
}
/**************
clearBoard: clears the screen, returns the Turtle to center
In: Turtle * turt
Out: none
Post: window is cleared, Turtle is in center
**************/
void clearBoard(Turtle * turt)
{
    char clearIt[] = "                                                    ";
    attron(COLOR_PAIR(5));
    move(1,1);
    for (int i = 1; i < 27; i++)
    {
        printw("%s",clearIt);
        move((i+1),1);
    }
    turtleHome(turt);
    move(34,2);
}
/*************
fd: moves the turtle forward
In: Turtle * turt, long modifier, penState pen, int penColor
Out: none
Post: turtle is moved forward
**************/
void fd(Turtle *turt, long modifier, penState pen, int penColor)
{
    if (pen == Down)
        mvaddch(turt->y,turt->x,'*');
    if (pen ==  Up)
    {
        attron(COLOR_PAIR(5));
        mvaddch(turt->y,turt->x,' ');
        attron(COLOR_PAIR(penColor));
    }
    for (int i = 0; i < modifier; i++)
    {
        if (turt->direct == 1) // 90 degrees
        {
            if (turt->y > 1)
            {
                turt->y--;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 2) // 60 degrees
        {
            if ((turt->y > 3) && (turt->x < 52))
            {
                turt->y = turt->y - 2;
                turt->x++;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 3) // 45 degrees
        {
            if ((turt->y > 1) && (turt->x < 52))
            {
                turt->y--;
                turt->x++;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 4) // 30 degrees
        {
            if ((turt->y > 1) && (turt->x < 51))
            {
                turt->y--;
                turt->x = turt->x + 2;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 5) // 0 degrees
        {
            if (turt->x < 52)
            {
                turt->x++;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 6) // 330 degrees
        {
            if ((turt->y < 27) && (turt->x < 51))
            {
                turt->y++;
                turt->x = turt->x + 2;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 7) // 315 degrees
        {
            if ((turt ->y < 27) && (turt->x < 52))
            {
                turt->y++;
                turt->x++;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 8) // 300 degrees
        {
            if ((turt->y < 26) && (turt->x < 52))
            {
                turt->y = turt->y + 2;
                turt->x++;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 9) // 270 degrees
        {
            if (turt->y < 27)
            {
                turt->y++;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 10) // 240 degrees
        {
            if ((turt->y < 26) && (turt->x > 1))
            {
                turt->y = turt->y + 2;
                turt->x--;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 11) // 225 degrees
        {
            if ((turt->y < 27) && (turt->x > 1))
            {
                turt->y++;
                turt->x--;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 12) // 210 degrees
        {
            if ((turt->y < 27) && (turt->x > 2))
            {
                turt->y++;
                turt->x = turt->x - 2;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 13) // 180 degrees
        {
            if (turt->x > 1)
            {
                turt->x--;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 14) // 150 degrees
        {
            if ((turt->y > 1) && (turt->x > 2))
            {
                turt->y--;
                turt->x = turt->x - 2;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 15) // 135 degrees
        {
            if ((turt->y > 1) && (turt->x > 1))
            {
                turt->y--;
                turt->x--;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 16) // 120 degrees
        {
            if ((turt->y > 2) && (turt->x > 1))
            {
                turt->y = turt->y - 2;
                turt->x--;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        // only prints a character if pen is down
        if (pen == Down)
            mvaddch(turt->y,turt->x,'*');
    }
    mvaddch(turt->y,turt->x,'O');
    move(34,2);
}
/***********
bk: moves turtle backwards 
In: Turtle * turt, long modifier, penState pen, int penColor
Out: none
Post: Turtle is moved backwards along angle of travel
**********/
void bk(Turtle *turt, long modifier, penState pen, int penColor)
{
    if (pen == Up)
        mvaddch(turt->y,turt->x,'*');
    if (pen == Down)
    {
        attron(COLOR_PAIR(5));
        mvaddch(turt->y,turt->x,' ');
        attron(COLOR_PAIR(penColor));
    }
    for (int i = 0; i < modifier; i++)
    {
        if (turt->direct == 9) // 270 degrees
        {
            if (turt->y > 1)
            {
                turt->y--;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 10) // 240 degrees
        {
            if ((turt->y > 3) && (turt->x < 52))
            {
                turt->y = turt->y - 2;
                turt->x++;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 11) // 225 degrees
        {
            if ((turt->y > 1) && (turt->x < 52))
            {
                turt->y--;
                turt->x++;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 12) // 210 degrees
        {
            if ((turt->y > 1) && (turt->x < 51))
            {
                turt->y--; 
                turt->x = turt->x + 2;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 13) // 180 degrees
        {
            if (turt->x < 52)
            {
                turt->x++;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 14) // 150 degrees
        {
            if ((turt->y < 27) && (turt->x < 51))
            {
                turt->y++;
                turt->x = turt->x + 2;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 15) // 135 degrees
        {
            if ((turt ->y < 27) && (turt->x < 52))
            {
                turt->y++;
                turt->x++;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 16) // 120 degrees
        {
            if ((turt->y < 26) && (turt->x < 52))
            {
                turt->y = turt->y + 2;
                turt->x++;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 1) // 90 degrees
        {
            if (turt->y < 27)
            {
                turt->y++;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 2) // 60 degrees
        {
            if ((turt->y < 26) && (turt->x > 1))
            {
                turt->y = turt->y + 2;
                turt->x--;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 3) // 45 degrees
        {
            if ((turt->y < 27) && (turt->x > 1))
            {
                turt->y++;
                turt->x--;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 4) // 30 degrees
        {
            if ((turt->y < 27) && (turt->x > 2))
            {
                turt->y++;
                turt->x = turt->x - 2;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 5) // 0 degrees
        {
            if (turt->x > 1)
            {
                turt->x--;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 6) // 330 degrees
        {
            if ((turt->y > 1) && (turt->x > 2))
            {
                turt->y--;
                turt->x = turt->x - 2;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 7) // 315 degrees
        {
            if ((turt->y > 1) && (turt->x > 1))
            {
                turt->y--;
                turt->x--;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        else if (turt->direct == 8) // 300 degrees
        {
            if ((turt->y > 2) && (turt->x > 1))
            {
                mvaddch(turt->y,turt->x,'*'); 
                turt->y = turt->y - 2;
                turt->x--;
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("You've hit a wall!");
                attron(COLOR_PAIR(penColor));
            }
        }
        if (pen == Down)
            mvaddch(turt->y,turt->x, '*');
    }
    mvaddch(turt->y,turt->x,'O');
    move(34,2);
}
/***********
rt: rotates the Turtle's direction angle clockwise by a specified amount
In: Turtle * turt, long modifier)
Out: none
Post: turtle's direction of travel is altered
***********/
void rt(Turtle *turt, long modifier)
{
    if (modifier == 30)
    {
        if ((turt->direct == 3)||(turt->direct == 7)|| (turt->direct == 11)||
            (turt->direct == 15)||(turt->direct == 11))
        {
            move(31,2);
            printw("I don't know how to 30");
        }
        else if (turt->direct == 1)
        {
            turt->direct = 2;
        }
        else if (turt->direct == 2)
        {
            turt->direct = 4;
        }
        else if (turt->direct == 4)
        {
            turt->direct = 5;
        }
        else if (turt->direct == 5)
        {
            turt->direct = 6;
        }
        else if (turt->direct == 6)
        {
            turt->direct = 8;
        }
        else if (turt->direct == 8)
        {
            turt->direct = 9;
        }
        else if (turt->direct == 9)
        {
            turt->direct = 10;
        }
        else if (turt->direct == 10)
        {
            turt->direct = 12;
        }
        else if (turt->direct == 12)
        {
            turt->direct = 13;
        }
        else if (turt->direct ==13)
        {
            turt->direct = 14;
        }
        else if (turt->direct == 14)
        {
            turt->direct = 16;
        }
        else if (turt->direct == 16)
        {
            turt->direct = 1;
        }
    }
    else if (modifier == 45)
    {
        if ((turt->direct == 2)||(turt->direct == 4)||(turt->direct == 6)||
            (turt->direct == 8)||(turt->direct == 10)||(turt->direct == 12)||
            (turt->direct == 14)||(turt->direct == 16))
        {
            move(31,2);
            printw("I don't know how to 45");
        }
        else if (turt->direct == 1)
        {
            turt->direct = 3;
        }
        else if (turt->direct == 3)
        {
            turt->direct = 5;
        }
        else if (turt->direct == 5)
        {
            turt->direct = 7;
        }
        else if (turt->direct == 7)
        {
            turt->direct = 9;
        }
        else if (turt->direct == 9)
        {
            turt->direct = 11;
        }
        else if (turt->direct == 11)
        {
            turt->direct = 13;
        }
        else if (turt->direct == 13)
        {
            turt->direct = 15;
        }
        else if (turt->direct == 15)
        {
            turt->direct = 1;
        }
    }
    else if (modifier == 90)
    {
        if ((turt->direct == 2)||(turt->direct == 4)||
            (turt->direct == 6)||(turt->direct == 8)||
            (turt->direct == 10)||(turt->direct == 12)||
            (turt->direct == 14)||(turt->direct == 16))
        {
            move(31,2);
            printw("I don't know how to 90");
        }
        else if (turt->direct == 1)
        {
            turt->direct = 5;
        }
        else if (turt->direct == 3)
        {
            turt->direct = 7;
        }
        else if (turt->direct == 5)
        {
            turt->direct = 9;
        }
        else if (turt->direct == 7)
        {
            turt->direct = 11;
        }
        else if (turt->direct == 9)
        {
            turt->direct = 13;
        }
        else if (turt->direct == 11)
        {
            turt->direct = 15;
        }
        else if (turt->direct == 13)
        {
            turt->direct = 1;
        }
        else if (turt->direct == 15)
        {
            turt->direct = 3;
        }
    }
    else
    {
        move(31,2);
        printw("I don't know how to %ld",modifier);
    }
    move(34,2);
}
/*************
lt: rotates the turtle counter-clockwise by a specified angle
In: Turtle * turt, long modifier)
Out: none
Post: turtle's direction of travel is altered
************/
void lt(Turtle *turt, long modifier)
{
    if (modifier == 30)
    {
        if ((turt->direct == 3)||(turt->direct == 7)|| (turt->direct == 11)||
            (turt->direct == 15)||(turt->direct == 11))
        {
            move(31,2);
            printw("I don't know how to 30");
        }
        if (turt->direct == 1)
            turt->direct = 16;
        if (turt->direct == 2)
            turt->direct = 1;
        if (turt->direct == 4)
            turt->direct = 2;
        if (turt->direct == 5)
            turt->direct = 4;
        if (turt->direct == 6)
            turt->direct = 5;
        if (turt->direct == 8)
            turt->direct = 6;
        if (turt->direct == 9)
            turt->direct = 8;
        if (turt->direct == 10)
            turt->direct = 9;
        if (turt->direct == 12)
            turt->direct = 10;
        if (turt->direct ==13)
            turt->direct = 12;
        if (turt->direct == 14)
            turt->direct = 13;
        if (turt->direct == 16)
            turt->direct = 14;
    }
    if (modifier == 45)
    {
        if ((turt->direct == 2)||(turt->direct == 4)||(turt->direct == 6)||
            (turt->direct == 8)||(turt->direct == 10)||(turt->direct == 12)||
            (turt->direct == 14)||(turt->direct == 16))
        {
            move(31,2);
            printw("I don't know how to 45");
        }
        if (turt->direct == 1)
            turt->direct = 15;
        if (turt->direct == 3)
            turt->direct = 1;
        if (turt->direct == 5)
            turt->direct = 3;
        if (turt->direct == 7)
            turt->direct = 5;
        if (turt->direct == 9)
            turt->direct = 7;
        if (turt->direct == 11)
            turt->direct = 9;
        if (turt->direct == 13)
            turt->direct = 11;
        if (turt->direct == 15)
            turt->direct = 13;
    }
    if (modifier == 90)
    {
        if ((turt->direct == 2)||(turt->direct == 3)||(turt->direct == 4)||
            (turt->direct == 6)||(turt->direct == 7)||(turt->direct == 8)||
            (turt->direct == 10)||(turt->direct == 11)||(turt->direct == 12)||
            (turt->direct == 14)||(turt->direct == 15)||(turt->direct == 16))
        {
            move(31,2);
            printw("I don't know how to 90");
        }
        if (turt->direct == 1)
            turt->direct = 13;
        if (turt->direct == 5)
            turt->direct = 1;
        if (turt->direct == 9)
            turt->direct = 5;
        if (turt->direct == 13)
            turt->direct = 9;
    }
    move(34,2);
}
