/*********************
Student Name: Timothy Bratcher      Student Number:0902130
Date: February 13, 2015             Course Name: CIS2500
I have exclusive control over this submission via my password.
By including this statement in this header comment, I certify that:
    1)I have read and understood the University policy on academic integrity;
    2)I have completed the Computing with Integrity Tutorial on Moodle; and
    3)I have achieved at least 80% in the Computing with Integrity Self Test.
I assert that this work is my own. I have appropriately acknowledged any and all material
(data, images, ideas or words) that I have used, whether directly quoted or paraphrased.
Furthermore, I certify that this assignment was prepared by me specifically for this course.
*********************/
#include "logoInt.h"
#define BUFFSIZE 19

int main(void)
{
    struct Turtle turt;
    Turtle * turtPtr = malloc(sizeof(turt));
    char input[20];
    char inputCpy[20];
    char * commandPtr;
    char * modPtr;
    char * token;
    char * temp;
    long modifier;
    penState pen = Down;
    char clear[] = "                                                 ";
    int colorTrack = 5;
    char * * commArray;
    FILE * ofp;
    char outFile[] = "assets/saveFile.txt";
    int arrayi = 0;
    commArray = malloc(sizeof(char*)*50);

    // start ncurses, initiate color schemes
    initscr();
    cbreak();
    start_color();
    init_pair(1, COLOR_RED, COLOR_RED);
    init_pair(2, COLOR_GREEN, COLOR_GREEN);
    init_pair(3, COLOR_YELLOW, COLOR_YELLOW);
    init_pair(4, COLOR_BLUE, COLOR_BLUE);
    init_pair(5, COLOR_WHITE, COLOR_BLACK);
    attron(COLOR_PAIR(colorTrack));
    drawScreen();
    // initiialize and place the turtle
    turtleHome(turtPtr);
    move(34,2);

    // start getting input
    getnstr(input, BUFFSIZE);
    strcpy(inputCpy,input); //retains a clean copy of the input stream to save to file
    token = strtok(input, " ");

    while (token == NULL)  // if blank, ask for new input
    {
        move(34,2);
        getnstr(input,BUFFSIZE);
        strcpy(inputCpy,input);
        token = strtok(input, " ");
    }
    if (token != NULL) // accepts first parsed string as the command
    {
        commandPtr = malloc(sizeof(token));
        strcpy(commandPtr,token);
        commArray[arrayi] = malloc(sizeof(char)*(strlen(inputCpy)+1));
        strcpy(commArray[arrayi],inputCpy);
        arrayi++;
    }
        // main loop
    while (strcmp(commandPtr, "quit") != 0)
    {
        token = strtok(NULL, " ");
        if (token == NULL)  // if there is no second command, attempt to execute single-parameter commands
        {
            attron(COLOR_PAIR(5));
            move(34,2);
            printw("%s",clear);
            move(34,2);
            attron(COLOR_PAIR(colorTrack));
            if (strcmp(commandPtr, "pu") == 0)
            {
                pen = Up;
            }
            else if (strcmp(commandPtr, "pd") == 0)
            {
                pen = Down;
            }
            else if (strcmp(commandPtr, "home") == 0)
            {
                turtleHome(turtPtr);
            }
            else if (strcmp(commandPtr, "save") == 0) // saves all commands so far into /assets/saveFile.txt
            {
                ofp = fopen(outFile, "w");
                for (int i = 0; i < (arrayi - 1); i++)
                {
                    fprintf(ofp,"%s\n",commArray[i]);
                }
                fclose(ofp);
            }
            else if (strcmp(commandPtr, "clear") == 0)
            {
                clearBoard(turtPtr);
            }
            else if (strcmp(commandPtr, "restart")== 0)
            {
                for (int k = (arrayi - 1); k > -1; k--)
                {
                    commArray[k] = "";
                }
                arrayi = 0;
                clearBoard(turtPtr);
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("I don't know how to %s",commandPtr);
                attron(COLOR_PAIR(colorTrack));
            }
        }
        else if (token != NULL) // if thre is a second command, set it as the modifier, attempt 2-parameter commands
        {
            modPtr = malloc(sizeof(token));
            strcpy(modPtr,token);
            modifier = strtol(modPtr,&temp,0);
            move(34,2);
            attron(COLOR_PAIR(5));
            printw("%s",clear);
            attron(COLOR_PAIR(colorTrack));
            if (strcmp(commandPtr, "fd") == 0)
            {
                if (modifier < 1)
                {
                    move(31,2);
                    attron(COLOR_PAIR(5));
                    printw("I don't know how to %s %s",commandPtr,modPtr);
                    attron(COLOR_PAIR(colorTrack));
                }
                else
                {
                    fd(turtPtr,modifier,pen,colorTrack);
                }
            }
            else if (strcmp(commandPtr, "bk") == 0)
            {
                if (modifier < 1)
                {
                    move(31,2);
                    attron(COLOR_PAIR(5));
                    printw("I don't know how to %s %s",commandPtr,modPtr);
                    attron(COLOR_PAIR(colorTrack));
                }
                else
                {
                    bk(turtPtr,modifier,pen,colorTrack);
                }
            }
            else if (strcmp(commandPtr, "rt") == 0)
            {
                if (modifier < 1)
                {
                    move(31,2);
                    attron(COLOR_PAIR(5));
                    printw("I don't know how to %s %s",commandPtr,modPtr);
                    attron(COLOR_PAIR(colorTrack));
                }
                else
                {
                    rt(turtPtr,modifier);
                }
            }
            else if (strcmp(commandPtr, "lt") == 0)
            {
                if (modifier < 1)
                {
                    move(31,2);
                    attron(COLOR_PAIR(5));
                    printw("I don't know how to %s %s",commandPtr,modPtr);
                    attron(COLOR_PAIR(colorTrack));
                }
                else
                {
                    lt(turtPtr,modifier);
                }
            }
            else if (strcmp(commandPtr, "setpencolor") == 0)
            {
                if (strcmp(modPtr,"blue") == 0)
                {
                    attron(COLOR_PAIR(4));
                    colorTrack = 4;
                }
                else if (strcmp(modPtr,"red") == 0)
                {
                    attron(COLOR_PAIR(1));
                    colorTrack = 1;
                }
                else if (strcmp(modPtr,"green") == 0)
                {
                    attron(COLOR_PAIR(2));
                    colorTrack = 2;
                }
                else if (strcmp(modPtr,"yellow") == 0)
                {
                    attron(COLOR_PAIR(3));
                    colorTrack = 3;
                }
                else if (strcmp(modPtr,"default") == 0)
                {
                    attron(COLOR_PAIR(5));
                    colorTrack = 5;
                }
                else
                {
                    move(31,2);
                    attron(COLOR_PAIR(5));
                    printw("I don't know how to %s",modPtr);
                    move(34,2);
                    attron(COLOR_PAIR(colorTrack));
                }
            }
            else
            {
                move(31,2);
                attron(COLOR_PAIR(5));
                printw("I don't know how to %s %s",commandPtr,modPtr);
                move(34,2);
                attron(COLOR_PAIR(colorTrack));
            }
        }
        attron(COLOR_PAIR(5));
        move(34,2);
        getnstr(input, BUFFSIZE);
        strcpy(inputCpy,input);
        token = strtok(input, " ");
        while (token == NULL)
        {
            move(34,2);
            getnstr(input, BUFFSIZE);
            strcpy(inputCpy,input); //retains a clean copy to save to file
            token = strtok(input, " ");
        }
        if (token != NULL)
        {
            commandPtr = malloc(sizeof(token));
            strcpy(commandPtr,token);
            commArray[arrayi] = malloc(sizeof(char)*(strlen(inputCpy)+1));
            strcpy(commArray[arrayi],inputCpy);
            arrayi++;
            move(31,2);
            printw("%s",clear);
            move(34,2);
            attron(COLOR_PAIR(colorTrack));
        }
    }
    endwin();
    // free the memory
    for (int k = 0; k < (arrayi); k++)
    {
        free(commArray[k]);
    }
    free(turtPtr);
    free(commandPtr);
    free(modPtr);
    free(commArray);
    return 0;
}


