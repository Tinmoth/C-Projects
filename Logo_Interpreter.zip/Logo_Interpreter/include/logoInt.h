#ifndef _TBRATCHE_LOGOINTH
#define _TBRATCHE_LOGOINTH

#include <stdlib.h>
#include <ncurses.h>
#include <string.h>
// typedefs
typedef struct Turtle
{
    int x;
    int y;
    int direct;
}Turtle;

typedef enum penState
{
    Up,
    Down
}penState;
// function protos
void drawScreen(void);
void moveTurtle(Turtle *turt, int newY, int newX); //not implemented
void turtleHome(Turtle *turt);
void clearBoard(Turtle *turt);
void fd(Turtle *turt, long modifier, penState pen, int penColor);
void bk(Turtle *turt, long modifier, penState pen, int penColor);
void rt(Turtle *turt, long modifier);
void lt(Turtle *turt, long modifier);
#endif
