Student Name: Timothy Bratcher
ID: 0902130
Course: CIS2500
Date: February 13, 2015

Filename: a2.c, logoInt.c
Header file: logoInt.h

Compiling:
gcc -Wall -pedantic -std=c99 /src/logoInt.c /src/a2.c -Iinclude -o filename -lncurses

Running:
./bin/runMe

Limitations:
back-tracking on a line can result in a blank space if the Turtle 
lands on the middle of an existing line


Notes:
"Clear" function implemented for bonus
"Restart" function erases prior commands ('save' won't print them to file)
and implements the 'clear' function.

To implement 'load from file', a loop could read strings from 'saveFile.txt' 
tokenized by '\n', then saved to a string array similar to the one used in the 
'save' function. They could then be fed via loop into the main program.

The addition of other angles (or approximations of them) could be implemented
in a way identical to 30, 45, and 90. Adding increments of 15 degrees would 
require 8 more 'direction' values, and would enable a 30 degree 
rotation from 45, 135, or 225 (currently disallowed)


