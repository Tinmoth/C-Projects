#ifndef _TBRATCHE_FUNCTIONSH
#define _TBRATCHE_FUNCTIONSH
#include <stdio.h>
#include <stdlib.h>
#include "queue.h"


void parse_threads(FILE * infile, tQueue * threads, int procno);

void proc_fcfs(tQueue * threads, tQueue * finished, int * clck, int verbose, int * curr_proc, int * cpu_burst_counter, int toverhead, int poverhead);
void proc_rr(tQueue * ready, tQueue * finished, int * clck, int v_flag, int * curr_proc, int * cpu_burst_counter, int toverhead, int poverhead, int quantum);
int same(Thread * previous, Thread * current);
Thread * get_source(tQueue * ready, tQueue * blocked, int * get_source);
void output_details(int total_threads, int s_scheme, int avg_turnaround_all, int total_cpu_util, tQueue * finished, int d_flag);

#endif