#include <stdio.h>
#include <stdlib.h>
	
#include "functions.h"
#include "queue.h"
void parse_threads(FILE * infile, tQueue * threads, int procno)
{
	int a, b, c;
	int procid;
	int threadno;
	int i,j,k;
	Thread * new_thread;
	
	for (i = 0; i < procno; i++) /*for each process*/
	{
		fscanf(infile, "%d%d",&a,&b); /*get process number, number of threads */
//		printf("%d %d\n",a,b);
		procid = a;
		threadno = b;
		for (j = 0; j < threadno; j++) /*for each thread*/
		{
			new_thread = malloc(sizeof(Thread)* 1);
			new_thread->owner_process = procid;
			new_thread->cur_burst = 0;
			new_thread->io_time = 0;
			new_thread->cpu_time = 0;
			new_thread->state = 1;
			fscanf(infile, "%d%d%d",&a,&b,&c); /*get threadid, arrive time, burst count*/
//			printf("%d %d %d\n",a,b,c);
			new_thread->thread_number = a;
			new_thread->arrive_time = b;
			new_thread->allowed = b;
			new_thread->num_bursts = c;
			new_thread->bursts = malloc(sizeof(Burst)*c);
			for (k = 0; k < (new_thread->num_bursts - 1); k++) /*for each burst except last*/
			{
				fscanf(infile, "%d%d%d",&a,&b,&c);/*get burst number, cpu time, io time*/
//				printf("%d %d %d\n",a,b,c);
				new_thread->bursts[k].burst_id = a;
				new_thread->bursts[k].cpu = b;
				new_thread->bursts[k].io = c;
			}
			fscanf(infile, "%d%d", &a, &b); /*get final burst info*/
//			printf("%d %d\n",a,b);
			new_thread->bursts[new_thread->num_bursts - 1].burst_id = a;
			new_thread->bursts[new_thread->num_bursts - 1].cpu = b;
			new_thread->bursts[new_thread->num_bursts - 1].io = 0;

			/*add to queue*/
			insert_at(new_thread, threads);
			
		}/*thread fetch loop*/
	}/*process fetch loop*/
	fclose(infile);
}
void proc_fcfs(tQueue * ready, tQueue * finished, int * clck, int verbose, int * curr_proc, int * cpu_burst_counter, int toverhead, int poverhead)
{
	Thread * current;
	tQueue * blocked;
//	int i;
//	int source_flag;
	int first = 1;
	blocked = init_queue();
		
	while ((ready->count != 0)||(blocked->count != 0)) /*do until both are empty*/
	{
//		printf("%d ready, %d blocked\n",ready->count, blocked->count);
		/*check blocked queue*/
		if (blocked->count > 0)
		{
			while (blocked->count > 0)
			{
				if (blocked->first->allowed < *clck)
				{
					current = remove_from_front(blocked);
					if (verbose == 1)
					{
						printf("At time %d: Thread %d of Process %d moves from blocked to ready\n",current->allowed, current->thread_number, current->owner_process);
					}
					current->state = 2;
					insert_at(current, ready);
				}
				else
					break;
//				printf("%d ready, %d blocked\n",ready->count, blocked->count);
			}
		}
		/*get a thread */
		if (ready->count == 0)
			current = remove_from_front(blocked);
		else
			current = remove_from_front(ready);
		/* perform action */
		/* update clock */
		if (*clck < current->allowed)
			*clck = current->allowed;
		if (verbose == 1)
		{
			if (current->state == 1)
			{	
				printf("At time %d: Thread %d of Process %d moves from new to ready\n",*clck, current->thread_number, current->owner_process);
			}
		}
		if (current->state == 1)
			current->state = 2;
		/* update clock */
		
		/*exclude overhead on very first thread*/
		if (first != 1)
		{
			if (*curr_proc != current->owner_process)
				*clck = *clck + poverhead;
			else
				*clck = *clck + toverhead;
		}
		if (first == 1)
			first = 0;
		*curr_proc = current->owner_process;
		current->start_time = *clck;
		if (verbose == 1){ printf("At time %d: Thread %d of Process %d moves from ready to running\n",*clck, current->thread_number, current->owner_process); }
		current->state = 3;			
		/*execute CPU burst */
		*clck = *clck + current->bursts[current->cur_burst].cpu;
		*cpu_burst_counter = *cpu_burst_counter + current->bursts[current->cur_burst].cpu;
		current->cpu_time = current->cpu_time + current->bursts[current->cur_burst].cpu;
		if (verbose == 1){ printf("At time %d: Thread %d of Process %d finishes CPU burst %d\n",*clck, current->thread_number, current->owner_process, (current->cur_burst + 1)); }
		/* if io time, send to blocked */
		if (current->bursts[current->cur_burst].io != 0)
		{
			if (verbose == 1){ printf("At time %d: Thread %d of Process %d moves from running to blocked\n",*clck, current->thread_number, current->owner_process); }
			current->state = 4;
			current->io_time = current->io_time + current->bursts[current->cur_burst].io;
			current->allowed = *clck + current->bursts[current->cur_burst].io; /* this is when it may return to ready */
			current->cur_burst++;
			insert_at(current, blocked);
		}
		else /* it's the last burst */
		{
			current->cur_burst++;
			if (current->cur_burst == current->num_bursts)
			{
				/*thread finished*/
				current->done_time = *clck;
				current->turnaround = current->done_time - current->arrive_time;
				if (verbose == 1)
				{ 
					printf("At time %d: Thread %d of Process %d moves from running to terminated\n",*clck, current->thread_number, current->owner_process); 
					print_thread_details(current);
				}
				current->state = 5;
				current->allowed = current->arrive_time;
				insert_at(current,finished);		
			}
		}
	}/*end while*/
	destroy(blocked);
}
void proc_rr(tQueue * ready, tQueue * finished, int * clck, int verbose, int * curr_proc, int * cpu_burst_counter, int toverhead, int poverhead, int quantum)
{
	Thread * current;
	tQueue * blocked;
	int prev_thread;
	blocked = init_queue();
	int first = 1;
		
	while ((ready->count != 0)||(blocked->count != 0)) /*do until both are empty*/
	{
		/*check blocked queue*/
		if (blocked->count > 0)
		{
			while (blocked->count > 0)
			{
				if (blocked->first->allowed < *clck)
				{
					current = remove_from_front(blocked);
					if (verbose == 1)
					{
						printf("At time %d: Thread %d of Process %d moves from blocked to ready\n",current->allowed, current->thread_number, current->owner_process);
					}
					current->state = 2;
					insert_at(current, ready);
				}
				else
					break;
			}
		}
		/*get a thread */
		if (ready->count == 0)
			current = remove_from_front(blocked);
		else
			current = remove_from_front(ready);
		/* perform action */
		/* update clock */
		if (*clck < current->allowed)
			*clck = current->allowed;
		if (verbose == 1)
		{
			if (current->state == 1)
			{	
				printf("At time %d: Thread %d of Process %d moves from new to ready\n",*clck, current->thread_number, current->owner_process);
			}
		}
		if (current->state == 1)
			current->state = 2;
		/* ADD OVERHEAD */
		if (first != 1)
		{
			/*if it's not the same process, use poverhead*/
			if (*curr_proc != current->owner_process)
				*clck = *clck + poverhead;
			else/*if its the same process*/
				*clck = *clck + toverhead;
		}
		if ((*curr_proc == current->owner_process)&&(current->thread_number == prev_thread))
			*clck = *clck - toverhead;

		if (first == 1)
			first = 0;
		*curr_proc = current->owner_process;
		current->start_time = *clck;
		if (verbose == 1){ printf("At time %d: Thread %d of Process %d moves from ready to running\n",*clck, current->thread_number, current->owner_process); }
		current->state = 3;			
		/*execute CPU burst */
		if ((current->bursts[current->cur_burst].cpu - quantum) > 0)
		{
//			printf("quantum met\n");
			*clck = *clck + quantum;
			current->allowed = *clck;
			/*subtract the quantum from the burst time*/
			current->bursts[current->cur_burst].cpu = current->bursts[current->cur_burst].cpu - quantum;
			*cpu_burst_counter = *cpu_burst_counter + quantum;
			current->cpu_time = current->cpu_time + quantum;
			if (verbose == 1)
			{
				printf("At time %d: Thread %d of Process %d exhausted quantum\n",*clck, current->thread_number, current->owner_process);
				printf("At time %d: Thread %d of Process %d moves from running to ready\n",*clck, current->thread_number, current->owner_process);
			}
			current->state = 2;
			/*DOES NOT UPDATE cur_burst*/
			prev_thread = current->thread_number;
			insert_at(current, ready);
		}
		else
		{	
			*clck = *clck + current->bursts[current->cur_burst].cpu;
			*cpu_burst_counter = *cpu_burst_counter + current->bursts[current->cur_burst].cpu;
			current->cpu_time = current->cpu_time + current->bursts[current->cur_burst].cpu;
			if (verbose == 1){ printf("At time %d: Thread %d of Process %d finishes CPU burst %d\n",*clck, current->thread_number, current->owner_process, (current->cur_burst + 1)); }
			/* if io time, send to blocked */
			if (current->bursts[current->cur_burst].io != 0)
			{
				if (verbose == 1){ printf("At time %d: Thread %d of Process %d moves from running to blocked\n",*clck, current->thread_number, current->owner_process); }
				current->state = 4;
				current->io_time = current->io_time + current->bursts[current->cur_burst].io;
				current->allowed = *clck + current->bursts[current->cur_burst].io; /* this is when it may return to ready */
				current->cur_burst++;
				prev_thread = current->thread_number;
				insert_at(current, blocked);
			}
			else /* it's the last burst */
			{
				current->cur_burst++;
				if (current->cur_burst == current->num_bursts)
				{
					/*thread finished*/
					current->done_time = *clck;
					current->turnaround = current->done_time - current->arrive_time;
					if (verbose == 1)
					{ 
						printf("At time %d: Thread %d of Process %d moves from running to terminated\n",*clck, current->thread_number, current->owner_process); 
						print_thread_details(current);
					}
					current->state = 5;
					current->allowed = current->arrive_time;
					prev_thread = current->thread_number;
					insert_at(current,finished);		
				}
			}
		}
	}/*end while*/
	destroy(blocked);
}
int same(Thread * previous, Thread * current)
{
	if ((previous->owner_process == current->owner_process)&&(previous->thread_number == current->thread_number))
		return 1;
	else
		return 0;
}
Thread * get_source(tQueue * ready, tQueue * blocked, int * source_flag)
{
	Thread * current;

	if ((ready->count != 0)&&(blocked->count == 0))
	{
		printf("fetching from ready\n");
		current = remove_from_front(ready);
		*source_flag = 1;
	}
	else if ((ready->count == 0)&&(blocked->count != 0))
	{
		printf("fetching from blocked\n");
		current = remove_from_front(blocked);
		*source_flag = 2;
	}
	else
	{
		printf("%d in ready, %d in blocked\n",ready->count, blocked->count);
		printf("%d vs %d\n",ready->first->allowed, blocked->first->allowed);
		if (ready->first->allowed <= blocked->first->allowed)
		{
			printf("from ready\n");
			current = remove_from_front(ready);
			*source_flag = 1;
		}
		else
		{
			printf("from blocked\n");
			current = remove_from_front(blocked);
			*source_flag = 2;
		}
	}
	return current;
}
void output_details(int total_threads, int s_scheme, int avg_turnaround_all, int total_cpu_util, tQueue * finished, int d_flag)
{
	int k;
	Thread * temp;

	if (s_scheme == 1)
		printf("FCFS Scheduling\n");
	else
		printf("Round Robin Scheduling\n");
	printf("Total Time required is %d time units\n",total_threads);
	printf("Average Turnaround Time of Processes is %d time units\n",avg_turnaround_all);
	printf("CPU Utilization is %d%%\n",total_cpu_util);

	if (d_flag == 1)
	{
		temp = finished->first;
		for (k = 0; k < finished->count; k++)
		{
			print_thread_details(temp);
			temp = temp->next;
		}
	}
}
