#ifndef _TBRATCHE_QUEUEH
#define _TBRATCHE_QUEUEH
#include <stdio.h>
#include <stdlib.h>

typedef struct Burst
{
	int burst_id;
	int cpu;
	int io;
}Burst;
typedef struct Thread
{
	int state; /*1 - new, 2 - ready, 3 - running - 4 - blocked, 5 - blocked*/
    int owner_process; /* to check overhead */
    int thread_number;
    int cur_burst;
    int num_bursts;
    int io_time;
    int cpu_time;
    Burst * bursts;
    int arrive_time;
    int allowed;
	int start_time;
	int done_time;
	int turnaround; /*done_time - start_time*/
	struct Thread * next; /*pointer to next in thread queue*/
}Thread;

typedef struct tQueue
{
	int count;
	struct Thread * first;
	struct Thread * last;
}tQueue;

/* creates a tQueue struct with no threads */
tQueue * init_queue();

/* returns 1 if empty, 0 if not empty */
int is_empty(tQueue * queue);

/* adds a Thread to the back of the tQueue */
void add_to_back(tQueue * queue_head, Thread * new_thread);

/* simple function adds to front of queue */
void add_to_front(tQueue * queue, Thread * new_thread);

/* returns the first Thread in the tQueue */
Thread * remove_from_front(tQueue * queue_head);

/* inserts a Thread at the proper part of the queue based on "arrival time" */
void insert_at(Thread * new_thread, tQueue * queue);

/* destroys all Threads in the tQueue. Destroys the tQueue */
void destroy(tQueue * queue);

/* prints arrive time of each Thread. Used for verifying schedule order */
void print_queue(tQueue * queue);

/* prints details after thread completion */
void print_thread_details(Thread * current);
#endif


