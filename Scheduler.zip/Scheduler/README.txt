Timothy Bratcher
St.ID: 0902130
Assignment 2
CIS 3110 Winter

CPU Simulation

Compiling:
Use Makefile OR
gcc -Wall -pedantic -std=c99 main.c functions.c queue.c -o simcpu

Run:
./simcpu [-d] [-v] [-r quantum] < filename.ext

NOTE: since input is redirected from from file to stdin, failure to enter filename results in prompt for manual entry.
NOTE: Manual entry will fail if filename was given without redirect command.

[-r] indicates Round Robin Scheduling. Default is FCFS Scheduling, in the absence of flag.
	'quantum' is an integer value and must follow [-r] flag. 

[-v] indicates Verbose Mode: all events announced as they occur.
    Events: change of thread state, including entry into queue, exit to block, reentry, exit after completion.

NOTE: transfers from Blocked Queue to Ready Queue that occur within a CPU Burst will be announced AFTER burst.
    (Time stamp will not be linear).

[-d] indicates Details Mode: Thread details will be displayed.

Default output is:
<scheduling algorithm>
<total time required to run all threads>
<average turnaround time of THREAD>
<CPU utilization/efficiency>

- this default output will be included regardless of flags
