#define _GNU_SOURCE
#include "queue.h"
#include "functions.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(int argc, char * argv[])
{
	int total_threads; /* equals clock at end */
	int total_cpu_util = 0; /* cpu_burst_counter / clock*/
	int cpu_burst_counter= 0;
	int avg_turnaround_all; /* avg turnaround of PROCESSES*/
	int toverhead;
	int num_procs;
	int poverhead;
	int clck = 0;
	int d_flag = 0;
	int v_flag = 0;
	int quantum;
//	char filename[25];
	int curr_proc = 0;
	int i,a,b,c;
	int s_scheme = 1;
	int num_threads;
	int procsum = 0;
	Thread * temp;
	tQueue * rqueue = init_queue();
	tQueue * finished = init_queue();

	for (i = 0; i < argc; i++)
	{
//		printf("%s ",argv[i]);
		if (strcmp(argv[i],"-d") == 0)
		{
			d_flag = 1;
		}
		else if (strcmp(argv[i], "-v") == 0)
		{
			v_flag = 1;
		}
		else if (strcmp(argv[i], "-r") == 0)
		{
			s_scheme = 2;
			quantum = atoi(argv[i+1]);
		}
	}

/*get number of processes and overhead info */
	fscanf(stdin, "%d%d%d",&a,&b,&c); 
	num_procs = a;
	toverhead = b;
	poverhead = c;
	parse_threads(stdin, rqueue, num_procs);
	num_threads = rqueue->count;

//	printf("number of threads: %d\n", rqueue->count);
	if (s_scheme == 1)
	{
//		printf("processing fcfs\n");	
		proc_fcfs(rqueue, finished, &clck, v_flag, &curr_proc, &cpu_burst_counter, toverhead, poverhead);
	}
	else
	{
//		printf("processing rr\n");
		proc_rr(rqueue, finished, &clck, v_flag, &curr_proc, &cpu_burst_counter, toverhead, poverhead, quantum);
	}
/*  calculate results */
	total_threads = clck;
	total_cpu_util = (cpu_burst_counter * 100) / clck;
	temp = finished->first;
	for (i = 0; i < finished->count; i++)
	{
		procsum = procsum + temp->turnaround;
		temp = temp->next;
	}
	
	avg_turnaround_all = procsum / num_threads;
	
	/*print results*/
	output_details(total_threads, s_scheme, avg_turnaround_all, total_cpu_util, finished, d_flag);

    destroy(rqueue);     
    destroy(finished);     
	return 0; 
}


