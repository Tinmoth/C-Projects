#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

tQueue * init_queue()
{
	tQueue * head = malloc(sizeof(tQueue)*1);
	head->count = 0;
	head->first = NULL;
	head->last = NULL;
	return head;
}
int is_empty(tQueue * queue)
{
	if (queue->count == 0)
		return 1;
	else
		return 0;
}
void add_to_back(tQueue * queue, Thread * new_thread)
{
	if (queue->count == 0)
	{
		queue->first = new_thread;
		queue->last = new_thread;
	}
	else
	{
		queue->last->next = new_thread;
		queue->last = new_thread;
	}
	queue->count = queue->count + 1;
}
void add_to_front(tQueue * queue, Thread * new_thread)
{
	new_thread->next = queue->first;
	queue->first = new_thread;
	queue->count = queue->count + 1;
}
Thread * remove_from_front(tQueue * queue_head)
{
	Thread * front;
	if (is_empty(queue_head) == 0)
	{
		front = queue_head->first;
		queue_head->first = queue_head->first->next;
		queue_head->count = queue_head->count - 1;
		return front;
	}
	else
	{
		return NULL;
	}
}
void insert_at(Thread * new_thread, tQueue * queue)
{
	int index = new_thread->allowed;
	Thread * temp;
	int inserted = 0;
	temp = queue->first;
	if (queue->count == 0)					/* if the queue is empty */
	{
		queue->first = new_thread;
		queue->last = new_thread;
	}
	else
	{
		/*special case, trying to get process 1 to stay BEFORE process 1*/
		if (index == queue->first->allowed)
		{
			if (new_thread->owner_process > queue->first->owner_process)
			{
				new_thread->next = queue->first->next;
				queue->first->next = new_thread;
			}
			else
			{
				new_thread->next = queue->first;
				queue->first = new_thread;
			} 
		}
		else if (index < queue->first->allowed) /*insert at beginning*/
		{
			new_thread->next = queue->first;
			queue->first = new_thread;
		}
		else if (index > queue->last->allowed)/*insert at end*/
		{
			queue->last->next = new_thread;
			queue->last = new_thread;
		}
		else								/*insert in middle*/
		{
			while (inserted == 0)
			{
				if (index == temp->next->allowed)
				{
					if (new_thread->owner_process < temp->next->owner_process)
					{
						new_thread->next = temp->next;
						temp->next = new_thread;
						inserted = 1;
					}
					else
					{
						new_thread->next = temp->next->next;
						temp->next->next = new_thread;
						inserted = 1;
					}
				}
				if (index < temp->next->allowed)
				{
					new_thread->next = temp->next;
					temp->next = new_thread;
 					inserted = 1;
				}
				else
				{
					temp = temp->next;
				}
			}
		}
	}
	queue->count = queue->count + 1;
}
void destroy(tQueue * queue)
{
	int x = queue->count;
	int i;
	Thread * temp;
	
	for (i = 0; i < x; i++)
	{
		temp = remove_from_front(queue);
		free(temp->bursts);
		free(temp);
	}
	free(queue);
}
void print_queue(tQueue * queue)
{
	int i;
	Thread * temp = queue->first;

	for (i = 0; i < queue->count; i++)
	{
		printf("%d\n",temp->arrive_time);
		temp = temp->next;
	}
}
void print_thread_details(Thread * current)
{
	printf("Thread %d of Process %d:\n",current->thread_number, current->owner_process);
	printf(" arrival time: %d\n",current->arrive_time);
	printf(" service time: %d units, I/O time: %d units, turnaround time: %d units, finish time: %d units\n",current->cpu_time, current->io_time, current->turnaround, current->done_time);
}