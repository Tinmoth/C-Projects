/* Name: Timothy Bratcher
   Student: 0902130
*/
#include "linkedList.h"

int main(void)
{
    int i = 0;
    int val;
    int len;
    listNode * newNode;
    int testData[5] = {-8,0,4,-7,3};
    listNode * list = createList();
 /* Initiate test of initNode(), addToFront(), and printList();*/
    printf("Testing initNode(), addToFront(), and printList()");
    for (i = 0; i < 5; i++)
    {
        newNode = initNode(testData[i]);
        addToFront(list, newNode);
        printf("Adding %d:\n",testData[i]);
        printList(list);
    }
/* Initiate test of removeFromFront()*/
    printf("Testing removeFromFront()\n");
    removeFromFront(list);
    printList(list);
/* Initiate test of getValue() */
    printf("Testing getValue()\n");
    val = -7;
    printf("    Value should be %d... value is %d\n",val,getValue(list));
/* Initiate test of getLength() */
    len = 4;
    printf("Testing getLength()...");
    if (getLength(list) == len)
        printf("Passed\n");
    else
        printf("Failed\n");
/* Initiate test of destroy() */
    printf("Testing destroy()...");
    destroy(list);
    if (list->next == NULL)
        printf("Passed\n");
    else
        printf("Failed\n");
    free(list);
    return(0);
}
