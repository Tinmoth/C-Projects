/*  Name: Timothy Bratcher
    Student: 0902130
*/
#include "linkedList.h"

listNode * createList ()
{
    listNode * head = malloc(sizeof(listNode)*1);
    head->nodeValue = 0;
    head->next = NULL;
    return head;
}
void addToFront(listNode * head, listNode * newNode)
{
    newNode->next = head->next;
    head->next = newNode;
    head->nodeValue++;
}

void printList(listNode * head)
{
	int i;
	listNode * current = head->next;
	for (i = 0; i < getLength(head); i++)
	{
	    printf("%d\n",current->nodeValue);
	    current = current->next;
	}
}
listNode * initNode(int value)
{
    listNode * newNode = malloc(sizeof(listNode)*1);
    newNode->nodeValue = value;
    newNode->next = NULL;
    return newNode;
}
int getValue(listNode * head)
{
    int j = head->next->nodeValue;
    return j;
}
int getLength(listNode * head)
{
    int k = head->nodeValue;
    return k;
}
void removeFromFront(listNode * head)
{
    if (head->next != NULL)
    {
        listNode * current = head->next;
        head->next = current->next;
        head->nodeValue--;
        free(current);
    }
    /* does nothing if list is empty */
}
void destroy(listNode * head)
{
    while (head->next != NULL)
    {
        removeFromFront(head);
    }
    /* head must be freed from main */
}
