Name: Timothy Bratcher
Student: 0902130
Lab 02, CIS2520

Filename: linkedList.c, Lab2Test.c
Header file: linkedList.h

Compiling:
gcc -Wall -ansi src/linkedList.c src/Lab2Test.c -Iinclude -o /bin/runMe

Running:
./bin/runMe

Testing:
1. program was tested using negative and positive numbers
2. as long as preconditions are met, all functions operate as specified

        
        
