﻿Assignment 1 – CIS 3110
Author: Timothy Bratcher	ID:0902130
References:
	Inspiration, but not code, from:
http://stephen-brennan.com/2015/01/16/write-a-shell-in-c/


Because I didn't know if I could count on space-delimited arguments in the shell, I implemented a Flex/Bison based parser. It made handling “<” “>” and “&” simpler.
Compile with: make
Relevant files: parser.y, parser.l, y.tab.c, y.tab.h, lex.yy.c
Execute with: ./cis3110sh

Function 1: exit
	Calls exit(0) to close the parent process. If any child processes are running in the background, their pid_t has been saved to an array, and a loop is called to send SIGKILL to each using the kill() function.
Tested with: “exit”

Function 2: a command with no arguments
	The command has been saved to the first element of an array of arguments, and the second array element is NULL. The array of arguments is passed in a child process to execvp(), which replaces the child process. The parent process waits for the child to return status.
Tested with: “ls” and “ps”

Function 3: a command with arguments
	The command and arguments have been saved to separate indeces of an array of arguments. The array of arguments is passed in a child process to execvp(). Identical algorithm to Function 2 – the only difference is that more than one argument has been saved to the array. The parent process waits for the child to return status. 
Tested with: “ls -l” and “ps aux”

Because I used a parser, Functions 2 and 3 were implemented simultaneously.

Function 4: a command with or without arguments running in the background
	fork() and exec() precisely as in function 3, but if the user has specified '&', the parents process does NOT wait for the child to return. The pid_t of the child is saved to an array so it can be explicitly killed on 'exit'.
Tested with: “gedit testfile.txt”, “gedit testfile.txt &”

Function 5: a command with/without arguments, redirected to file
	Upon receiving the token '>', saves the next argument received as a string.  Sets flag variable to 2. In child process, if flag is 2, calls freopen() and closing stdout, while opening the user-specified filename. Call to execvp() is as normal. 
Tested with: “ls -l > test.txt”

Function 6: a command with/without arguments, redirected from a file
	Algorithm similar to Function 5, but sets flag to 3. In child process, when flag is 3, freopen() closes stdin and replaces it with user-specified file. 
Tested with: “wc < test.txt”   (file created with function 5 test)

Function 7: Pipe output from one program to another
	NOT IMPLEMENTED

Advanced Functions NOT IMPLEMENTED
EXCEPT: Implemented “cd” command to change working directory.
NOTE: does not inform user if access denied, just fails.
