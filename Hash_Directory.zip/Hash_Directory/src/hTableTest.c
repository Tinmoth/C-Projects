/* Name: Timothy Bratcher
   Student: 0902130
*/
#include "hashTable.h"

int main(void)
{
    int hIndex;
    listNode * testNode;
    listNode * fetch;
    long long phn = 5198278354;
    char * last = "Bratcher";
    char * first = "Timothy";
    HashTable * hTable;
/*test createHashTable()*/
    printf("Testing hash table creation...");
    hTable = createHashTable(97);
    if (hTable == NULL)
        printf("Failed\n");
    else
        printf("Success\n");
/*test hash()*/
    printf("Testing hash() function...");
    hIndex = hash(phn, hTable);
    if (hIndex == 32)
    {
        printf("Success\n");
        printf("hash key = %d\n",hIndex);
    }
    else
        printf("Failed\n");
    testNode = initNode(last, first, phn);
/*test insertItem()*/
    printf("Testing insertItem() function...");
    insertItem(hTable,testNode);
    if (hTable->table[32]->nodeValue == 1)
    {
        printf("Success\n");
        printList(hTable->table[32]);
    }
    else
        printf("Failed\n");
/*test lookUp()*/
    printf("Testing lookUp() function...");
    fetch = lookUp(hTable,phn);
    if (fetch->phone == phn)
    {
        printf("Success\n");
        printf("Retrieved %s, %s, %lld\n",fetch->last, fetch->first, fetch->phone);
    }
    else
        printf("Failed\n");
    printf("Populating the Hash Table with data...\n");
    insertItem(hTable,initNode("Gibson","Kristen",6102773300));
    insertItem(hTable,initNode("Davis","Ellen",2152755543));
/*test print_hTable()*/
    printf("Testing print_hTable()...\n");
    print_hTable(hTable);
/*destroy Hash Table*/
    printf("Destroying Hash Table...");
    destroy_hTable(hTable);
    printf("Finished. Test concluded.\n");
    free(hTable);
    return 0;
}