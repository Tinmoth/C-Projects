/* Name: Timothy Bratcher
   Student: 0902130
*/
#include "linkedList.h"
#include "hashTable.h"
#include "directory.h"

int main (int argc, char * argv[])
{
    int choice = 0;
    HashTable * hTable;
    listNode * list;
    FILE * file;
    list = createList();
    hTable = createHashTable(97);
    listNode * dummy;
/*begin program*/

/*    file = open(argv[1]);*/
/*    loadFile(file, list, hTable);*/
    dummy = list;

    choice = printMenu();
    getchar();
    while (choice != 5)
    {
        exeCom(choice, list, hTable);
        choice = printMenu();
    }

/*fclose(file);*/

    return 0;
}

