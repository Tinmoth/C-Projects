/* Name: Timothy Bratcher
   Student: 0902130
*/
#include "linkedList.h"
#include "hashTable.h"

HashTable * createHashTable(int size)
{
    int i;
    HashTable * hTable = malloc(sizeof(HashTable)*1);
    hTable->table = malloc(sizeof(listNode*)*size);
    hTable->size = size;
    for (i = 0; i < size; i++)
    {
        hTable->table[i] = createList();
    }
    return hTable;
}
int hash(long long phone, HashTable * hTable)
{
    int hash;
    hash = (phone * 33) % hTable->size;
    return hash;
}
listNode * lookUp(HashTable * hTable, long long phone)
{
    listNode * found;
    int hashed;
    hashed = hash(phone,hTable);
    if (hTable->table[hashed]->next != NULL)
    {
        found = hTable->table[hashed]->next;
        while (found->phone != phone)
        {
            found = found->next;
        }
        return found;
    }
    else
    {
        printf("Entry not found\n");
        return NULL;
    }
}
void print_hTable(HashTable * hTable)
{
    int i;
    listNode * current;
    for (i = 0; i < hTable->size; i++)
    {
        if (hTable->table[i]->nodeValue > 0)
        {
            current = hTable->table[i];
            while (current->next != NULL)
            {
                printf("%s, %s: %lld\n",current->next->last,current->next->first,current->next->phone);
                current = current->next;
            }
        }
    }
}
void insertHashItem(HashTable * hTable, listNode * newItem)
{
    addToFront(hTable->table[hash(newItem->phone,hTable)], newItem);
}/*adds new item to the front of the list at hashtable index corresponding to newItem's phone number*/
void destroy_hTable(HashTable * hTable)
{
    int k;
    for (k = 0; k < hTable->size; k++)
    {
        destroyList(hTable->table[k]);
        free(hTable->table[k]);
    }
}