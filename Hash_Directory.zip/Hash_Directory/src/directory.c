/* Name: Timothy Bratcher
   Student: 1902130
*/
#include "hashTable.h"

int printMenu()
{
    int choice;
    printf("Menu:\n");
    printf("1. Add Contact\n");
    printf("2. Load File\n");
    printf("3. Print Directory\n");
    printf("4. Look up by #\n");
    printf("5. Quit\n");
    scanf("%d",&choice);
    return choice;
}
FILE * open(char * filename)
{
    char infile[20];
    strcpy(infile, filename);
    FILE * file = fopen(infile, "r");
    while (file == NULL)
    {
        printf("Bad file name, try again\n");
        scanf("%s",infile);
        file = fopen(infile, "r");
        getchar();
    }
    return file;
}
listNode * parseContact(char * inLine)
{
    listNode * newNode;
    char lastName[50];
    char firstName[50];
    double phon;
    long long phn;
    char * token;

    token = strtok(inLine,",");
    strcpy(firstName,token);
    token = strtok(NULL,",");
    strcpy(lastName,token);
    token = strtok(NULL,"");
    phon = atof(token);
    phn = phon;
    newNode = initNode(lastName,firstName,phn);
    return newNode;
}
void loadFile(FILE * file, listNode * list, HashTable * hTable)
{
    char inString[111];
    int buffer = 110;
    listNode * contact;
    while (fgets(inString,buffer,file) != NULL)
    {
        contact = parseContact(inString);
        insertAtAlpha(list,contact);
        insertHashItem(hTable,contact);
    }
}
void addNewContact(listNode * list,HashTable * hTable)
{
    char last[50];
    char first[50];
    long long phn;
    listNode * newItem;
    printf("Enter Last Name: \n");
    scanf("%s",last);
    getchar();
    printf("\nEnter First Name: \n");
    scanf("%s",first);
    getchar();
    printf("\nEnter Phone Number: (e.g. 1234567890)\n");
    scanf("%lld",&phn);
    getchar();
    newItem = initNode(last,first,phn);
    insertAtAlpha(list,newItem);
    insertHashItem(hTable,newItem);
}
void exeCom(int com, listNode * list, HashTable * hTable)
{
    FILE * com2;
    char com1[20];
    long long com4a;
    listNode * com4b;
    if (com == 1)
    {
        addNewContact(list,hTable);
    }
    else if (com == 2)
    {
        printf("Enter file name: \n");
        scanf("%s",com1);
        com2 = open(com1);
        loadFile(com2,list,hTable);
    }
    else if (com == 3)
    {
        printList(list);
    }
    else if (com == 4)
    {
        printf("Enter number to look up: \n");
        scanf("%lld",&com4a);
        getchar();
        com4b = lookUp(hTable,com4a);
        printf("%s, %s : %lld",com4b->last,com4b->first,com4b->phone);
    }
    else if (com == 5)
    {
        printf("Quitting...\n");
    }
    else
    {
        printf("Invalid Option; Try Again:\n");
        printMenu();
    }
}
