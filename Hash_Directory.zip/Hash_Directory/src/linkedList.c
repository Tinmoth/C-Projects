/*  Name: Timothy Bratcher
    Student: 0902130
*/
#include "linkedList.h"

listNode * createList ()
{
    listNode * head = malloc(sizeof(listNode)*1);
    head->nodeValue = 0;
    head->next = NULL;
    return head;
}
void addToFront(listNode * head, listNode * newNode)
{
    newNode->next = head->next;
    head->next = newNode;
    head->nodeValue++;
}

void printList(listNode * head)
{
    listNode * current = head->next;
    while(current != NULL)
    {
	printf("%s %s: %lld\n",current->first,current->last,current->phone);
	current = current->next;
    }
}
listNode * initNode(char * lastName, char * firstName, long long phone)
{
    listNode * newNode = malloc(sizeof(listNode)*1);
    newNode->last = malloc(sizeof(char)*50);
    strcpy(newNode->last, lastName);
    newNode->first = malloc(sizeof(char)*50);
    strcpy(newNode->first, firstName);
    newNode->phone = phone;
    return newNode;
}
int getValue(listNode * head)
{
    int j = head->next->nodeValue;
    return j;
}
int getLength(listNode * head)
{
    int k = head->nodeValue;
    return k;
}
void removeFromFront(listNode * head)
{
    if (head != NULL)
    {
        if (head->next != NULL)
        {
            listNode * current = head->next;
            head->next = current->next;
            head->nodeValue--;
            free(current->last);
            free(current->first);
            free(current);
        }
    }    /* does nothing if list is empty */
}
void insertAtIndex(listNode * head, listNode * newNode, int index)
{
    int i;
    listNode * dest = head;
    if (head != NULL)
    {
        if(head->next != NULL)
        {
            for (i = 0; i < index; i++)
            {
                dest = dest->next;
            }
            newNode->next = dest->next;
            dest->next = newNode;
        }/*inserts at proper index location*/
    }
}
void insertAtAlpha(listNode * head, listNode * newNode)
{
    listNode * current = head;
    if (head != NULL)
    {
        if (current->next == NULL)
        {
            current->next = newNode;
        }
        else if (current->next != NULL)
        {
            while (current->next != NULL)
            {
                if (strcmp(newNode->first,current->next->first) > 0)
                {
                     current = current->next;
                }
                else if (strcmp(newNode->first,current->next->first) < 0)
                {
                    newNode->next = current->next;
                    current->next = newNode;
                    break;
                }
                else if (strcmp(newNode->first, current->next->first) == 0)
                {
                    if (strcmp(newNode->last, current->next->last) > 0)
                    {
                        current = current->next;
                    }
                    else if ((strcmp(newNode->last, current->next->last) < 0)||
                             (strcmp(newNode->last, current->next->last) == 0))
                    {
                        newNode->next = current->next;
                        current->next = newNode;
                        break;
                    }
                }
            }
        }
    }
    head->nodeValue++;
}
void insertAtPhone(listNode * head, listNode * newNode)
{
    listNode * dest = head;
    if (head != NULL)
    {
        if(head->next != NULL)
        {
            while (newNode->phone > dest->next->phone)
            {
                dest = dest->next;
            }
            newNode->next = dest->next;
            dest->next = newNode;
        }/*inserts at proper phone location*/
        else
            head->next = newNode;
    }
}
listNode * peekAt(listNode * head, int index)
{
    int i;
    listNode * dest = head;
    if (head != NULL)
    {
        if(head->next != NULL)
        {
            for (i = 0; i < index; i++)
            {
                dest = dest->next;
            }
        }
    }
    return dest;
}
void destroyList(listNode * head)
{
    if (head != NULL)
    {
        while (head->next != NULL)
        {
            removeFromFront(head);
        }
    }
}/* memory for head must be freed elsewhere */
