/* Name: Timothy Bratcher
   Student: 0902130
*/
#ifndef _TBRATCHE_DIRECTORYH
#define _TBRATCHE_DIRECTORYH

#include "hashTable.h"
#include "linkedList.h"

/* printMenu()
purpose: prints menu and gets input from user
pre: none
post: returns user menu choice
*/
int printMenu();
/* open()
purpose: opens a file
pre: none
post: file is opened, or user is taken to menu
*/
FILE * open(char * filename);
/* parseContact()
pre: none
post: string is parsed into a listNode
*/
listNode * parseContact(char * inLine);
/* loadFile()
purpose: loads data in an open file into the Directory and hashes it to the table
pre: file has been successfully opened
post: data from file is added to list and table
*/
void loadFile(FILE * file, listNode * list, HashTable * hTable);
/* addNewContact()
purpose: adds a new contact to the directory
pre: none
post: new contact is created, added to directory and table
*/
void addNewContact(listNode * list, HashTable * hTable);
/* exeCom()
purpose: executes a command based on user input
pre: user has input command in printMenu()
post: appropriate function is called
*/
void exeCom(int com, listNode * list, HashTable * hTable);

#endif
