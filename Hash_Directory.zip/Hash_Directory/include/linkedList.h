/* Name: Timothy Bratcher
   Student: 0902130
*/
/*
This .h file's pseudocode was provided in the Lab instructions
*/

#ifndef _TBRATCHE_LINKEDLISTH
#define _TBRATCHE_LINKEDLISTH

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

typedef struct listNode
{
    int nodeValue;    
    char * first;
    char * last;
    long long phone;
    struct listNode * next;
}listNode;
/*
createList
purpose: creates a new list with a dummy node as head
pre: None
post: a new listNode is created
*/ 
listNode * createList();
/*
addFront
purpose: adds a node to the front of a linked list
pre: an initialized listNode is passed as a parameter
post: a listNode is added at the front of the list
*/
void addToFront(listNode * head, listNode * newNode);
/*
printList
purpose: prints out the formatted value of all nodes in the list
pre: a populated list is passed in (at least 1 non-dummy node)
post: none
*/
void printList(listNode * head);
/*
initNode
purpose: creates a new, unattached listNode
pre: a valid integer is passed in
post: a new listNode is created
*/
listNode * initNode(char * lastName, char * firstName, long long phone);
/*
getValue
purpose: retrieves value of lead node
pre: the list is initiated
post: none
*/
int getValue(listNode * head);
/*
length
purpose: returns the length of the list
pre: list is initialized
post: none
*/
int getLength(listNode * head);
/*
removeFromFront
purpose: removes the front node
pre: list is initialized
post: a node is removed and memory is freed
*/
void removeFromFront(listNode * head);
/*
insertAtIndex
purpose: inserts a new item at a desired index
pre: list is initialized
post: new element is inserted in list
*/
void insertAtIndex(listNode * head, listNode * newNode, int index);
/*
insertAtAlpha
purpose: inserts new element sorted alphabetically
pre: list is initiated
post: new node is inserted at proper place
*/
void insertAtAlpha(listNode * head, listNode * newNode);
/*
insertAtPhone
purpose: inserts new node based on phone number
pre: list is initialized
post: new node is added in correct spot
*/
void insertAtPhone(listNode * head, listNode * newNode);
/*
peekAt
purpose: retrieves node from middle
pre: list is populated
post: information is retrieved but not removed
*/
listNode * peekAt(listNode * head, int index);
/*
destroyList
pre: list is initialized
post: list is destroyed, memory freed
*/
void destroyList(listNode * head);

#endif


