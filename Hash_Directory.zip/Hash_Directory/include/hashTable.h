/*  Name: Timothy Bratcher
    Student: 0902130
*/
#ifndef _TBRATCHE_HASHTABLEH
#define _TBRATCHE_HASHTABLEH

#include "linkedList.h"

typedef struct HashTable
{
    listNode * * table;
    int size;
}HashTable;

/* createHashTable()
purpose: initiates an empty hash table
pre: none
post: hash table is created
*/
HashTable * createHashTable(int size);
/* hash()
purpose: retuns a hash value based on a key
pre: none
post: none
*/
int hash(long long phone, HashTable * hTable);
/* lookUp()
purpose: retrieves contact data based on phone number
pre: phone number is valid
post: contact info is printed
*/
listNode * lookUp(HashTable * hTable, long long phone);
/* print_hTable()
purpose: prints the hash table
pre: hash table is initialized
post: full array is printed
*/
void print_hTable(HashTable * hTable);
/* insertHashItem()
purpose: adds a new contact to the hash table
pre: table is initialized
post: new contact is referenced on table
*/
void insertHashItem(HashTable * hTable, listNode * newItem);
/* destroy_hTable()
purpose: destroys hash table, freeing memory of elements
pre: none
post: hash table is destroyed
*/
void destroy_hTable(HashTable * hTable);

#endif
